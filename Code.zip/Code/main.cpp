#include<iostream>
#include <GL/glew.h>
#include<GLFW/glfw3.h>
#include <GL/freeglut.h>
#include "Shader.h"
#include"Material.h"
#include<glm/glm.hpp>
#include<glm/gtc/matrix_transform.hpp>
#include<glm/gtc/type_ptr.hpp>
#include"Camera.h"
#include"LightDirectional.h"
#include"LightPoint.h"
#include"LightSpot.h"
#include"Mesh.h"
#include"Model.h"
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

using namespace std;


#pragma region Camera Declare

//Instantiate Camera Class��ʵ����һ�������
//Camera MyCamera(glm::vec3(0, 0, 3.0f), glm::vec3(0, 0, 0), glm::vec3(0, 1.0f, 0));
Camera MyCamera(glm::vec3(0, 140.0f, 500.0f), glm::radians(-45.0f), glm::radians(180.0f), glm::vec3(0, 1.0f, 0));
//Camera MyCamera1(glm::vec3(0, 140.0f, 1000.0f), glm::radians(-45.0f), glm::radians(180.0f), glm::vec3(0, 1.0f, 0));
#pragma endregion

#pragma region Light Declare
//ƽ�й�
LightDirectional MyLight(glm::vec3(50.0, 50.0f, -500.0f), //��Դλ��
											glm::vec3(glm::radians(45.0f), glm::radians(45.0f), 0),//��Դƫת��
											glm::vec3(0.0,0.0f,0.0f));//��Դ��ɫ

//���Դ
LightPoint MyLight0(glm::vec3(0.0f, -10.0f, -50.0f), //��Դλ��
								glm::vec3(glm::radians(45.0f), glm::radians(45.0f), 0),
								glm::vec3(1000.0f, 1000.0f,1000.0f));//��Դ��ɫ

//�۹��
LightSpot MyLightSpot(glm::vec3(0.0f, 5.0f, 0.0f), //��Դλ��
								glm::vec3(glm::radians(90.0f), 0, 0),
								100.0f*glm::normalize(glm::vec3(55.0, 192.0f, 103.0f)));//��Դ��ɫ

#pragma endregion

#pragma region Input Declare

float LastX;
float LastY;
bool firstMouse = true;
glm::vec3 modelposition=glm::vec3(0, 800.0f, 0.0f);
void processInput(GLFWwindow* window) {//�������
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) {
		glfwSetWindowShouldClose(window, true);
	}
	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {
		MyCamera.speedZ=1.5f;
		modelposition.z += MyCamera.speedZ;
	}
	else if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {
		MyCamera.speedZ = -1.5f;
		modelposition.z += MyCamera.speedZ;
	}
	else if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
		MyCamera.speedX = -1.5f;
		modelposition.x += MyCamera.speedX;
	}
	else if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
		MyCamera.speedX = 1.5f;
		modelposition.x += MyCamera.speedX;
	}
	else if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS) {
		MyCamera.speedY = 1.5f;
		modelposition.y += MyCamera.speedY;
	}
	else if (glfwGetKey(window, GLFW_KEY_Z) == GLFW_PRESS) {
		MyCamera.speedY = -1.5f;
		modelposition.y += MyCamera.speedY;
	}
	else
	{
		MyCamera.speedZ = 0;
		MyCamera.speedX = 0;
		MyCamera.speedY = 0;
	}	
}

void processInput1(GLFWwindow* window) {//�������
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) {
		glfwSetWindowShouldClose(window, true);
	}
	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {
		//MyCamera.speedZ = 1.0f;
		modelposition.z += -0.1f;
	}
	else if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {
		//MyCamera.speedZ = -1.0f;
		modelposition.z += 0.1f;
	}
	else if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
		//MyCamera.speedX = -1.0f;
		modelposition.x += -0.1f;
	}
	else if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
		//MyCamera.speedX = 1.0f;
		modelposition.x += 0.1f;
	}
	else if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS) {
		//MyCamera.speedY = 1.0f;
		modelposition.y += 0.1f;
	}
	else if (glfwGetKey(window, GLFW_KEY_Z) == GLFW_PRESS) {
		//MyCamera.speedY = -1.0f;
		modelposition.y += -0.1f;
	}
	else
	{
		MyCamera.speedZ = 0;
		MyCamera.speedX = 0;
		MyCamera.speedY = 0;
	}
}

void mouse_callback(GLFWwindow* window, double xPos, double yPos) {//���任�ӽ�
	if (firstMouse == true) {
		LastX = xPos;
		LastY = yPos;
		firstMouse = false;
	}
	float deltaX, deltaY;
	deltaX = xPos - LastX;
	deltaY = yPos - LastY;
	LastX = xPos;
	LastY = yPos;
	MyCamera.ProcessMouseMovement(-deltaX, -deltaY);
}

#pragma endregion

//����ͼƬ�ĺ���
unsigned int LoadImageToGPU(const char* filename,GLint internalFormate,GLenum format,int texSlot) {
	unsigned int TexBuffer;
	glGenTextures(1, &TexBuffer);//����һ��VAO���Ұ�ID������һ�е�VAO
	glActiveTexture(GL_TEXTURE0+texSlot);//����textureBuffer�еļ���λ��
	glBindTexture(GL_TEXTURE_2D, TexBuffer);//������buffer�󵽲���λ����	
	int width, height, nrChannel;
	stbi_set_flip_vertically_on_load(true);//��ת������ͼ
	unsigned char *data = stbi_load(filename, &width, &height, &nrChannel, 0);
	if (data) {
		glTexImage2D(GL_TEXTURE_2D, 0, internalFormate, width, height, 0, format, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		cout << "Load image failed." << endl;
	}
	stbi_image_free(data);
	return TexBuffer;
}

int main(int argc,char* argv[]) {
	bool pork = false;
	bool carrot = false;
	bool broccoli = false;
	bool sauce = false;
	bool earth = false;
	std::string exePath = argv[0];
	//std::cout << exePath.substr(0,exePath.find_last_of('\\'))+"\\model\\nanosuit.obj"<< std::endl;

	#pragma region Open a Window
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	//Open GLFW Window����
	GLFWwindow* MyWindow = glfwCreateWindow(800, 600, "My First Window", NULL, NULL);
	if (MyWindow == NULL) {
		printf("Open window failed.");
		glfwTerminate();
		return -1;
	}
	
	glfwMakeContextCurrent(MyWindow);//����ǰwindow��Ϊ��Ҫ�����ģ������window��
	glfwSetInputMode(MyWindow, GLFW_CURSOR, GLFW_CURSOR_DISABLED);//�ص������е����
	glfwSetCursorPosCallback(MyWindow, mouse_callback);

	//Init GLEW
	glewExperimental = true;//ʵ���ԵĹ�������Ϊtrue���̶�д��
	if (glewInit() != GLEW_OK) {
		printf("Init GLEW failed.");
		glfwTerminate();
		return -1;
	}
	glViewport(0, 0, 800, 600);//�����ӽǴ�С��OpenGLԤ����ʱ�뻭��Ϊ���棬˳ʱ��Ϊ����
	//glEnable(GL_CULL_FACE);//����GL�޳��湦��
	//glCullFace(GL_FRONT);//�޳�����
	//glCullFace(GL_BACK);//�޳�������
	//glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);//���
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_DEPTH_TEST);//����Z-Buffer����

	#pragma endregion

	#pragma region Init Shader Program
	Shader* MyShader = new Shader("vertexSource.vert", "FragmentSource.frag");//newһ��shader����
	Shader* MyShader1 = new Shader("vertexSource.vert", "FragmentSource.frag");//newһ��shader����
	Shader* MyShader2 = new Shader("vertexSource.vert", "FragmentSource.frag");//newһ��shader����
	Shader* MyShader3 = new Shader("vertexSource.vert", "FragmentSource.frag");//newһ��shader����
	Shader* MyShader4 = new Shader("vertexSource.vert", "FragmentSource.frag");//newһ��shader����
	Shader* MyShader5 = new Shader("vertexSource.vert", "FragmentSource.frag");//newһ��shader����
	Shader* MyShader6 = new Shader("vertexSource.vert", "FragmentSource.frag");//newһ��shader����
	Shader* MyShader7 = new Shader("vertexSource.vert", "FragmentSource.frag");//newһ��shader����
	Shader* MyShader8 = new Shader("vertexSource.vert", "FragmentSource.frag");//newһ��shader����
	Shader* MyShader9 = new Shader("vertexSource.vert", "FragmentSource.frag");//newһ��shader����
	Shader* MyShader10 = new Shader("vertexSource.vert", "FragmentSource.frag");//newһ��shader����
	#pragma endregion

	//������
	#pragma region Init Material
	Material* MyMaterial = new Material(MyShader,
										LoadImageToGPU("ShipTex.jpg", GL_RGB, GL_RGB, 1),//diffuse�������������ͼ
										LoadImageToGPU("container2_specular.png", GL_RGBA, GL_RGBA, 2),//specular�����淴����ͼ
										glm::vec3(1.0f, 1.0f, 1.0f),//ambient
										32.0f);//shininess

	Material* MyMaterial1 = new Material(MyShader1,
										LoadImageToGPU("food.png", GL_RGB, GL_RGB, 3),//diffuse�������������ͼ
										LoadImageToGPU("container2_specular.png", GL_RGBA, GL_RGBA, 2),//specular�����淴����ͼ
										glm::vec3(1.0f, 1.0f, 1.0f),//ambient
										32.0f);//shininess

	Material* MyMaterial2 = new Material(MyShader2,
										LoadImageToGPU("earth.jpg", GL_RGB, GL_RGB, 5),//diffuse�������������ͼ
										LoadImageToGPU("container2_specular.png", GL_RGBA, GL_RGBA, 2),//specular�����淴����ͼ
										glm::vec3(1.0f, 1.0f, 1.0f),//ambient
										32.0f);//shininess
	Material* MyMaterial3 = new Material(MyShader3,
										LoadImageToGPU("Sun.jpg", GL_RGB, GL_RGB, 7),//diffuse�������������ͼ
										LoadImageToGPU("container2_specular.png", GL_RGBA, GL_RGBA, 2),//specular�����淴����ͼ
										glm::vec3(1.0f, 1.0f, 1.0f),//ambient
										32.0f);//shininess

	Material* MyMaterial4 = new Material(MyShader4,
										LoadImageToGPU("Moon.png", GL_RGBA, GL_RGBA, 9),//diffuse�������������ͼ
										LoadImageToGPU("container2_specular.png", GL_RGBA, GL_RGBA, 2),//specular�����淴����ͼ
										glm::vec3(1.0f, 1.0f, 1.0f),//ambient
										32.0f);//shininess

	Material* MyMaterial5 = new Material(MyShader5,
										LoadImageToGPU("StarBackgound.jpg", GL_RGB, GL_RGB, 11),//diffuse�������������ͼ
										LoadImageToGPU("container2_specular.png", GL_RGBA, GL_RGBA, 2),//specular�����淴����ͼ
										glm::vec3(1.0f, 1.0f, 1.0f),//ambient
										32.0f);//shininess
	
	Material* MyMaterial6 = new Material(MyShader6,
										LoadImageToGPU("ingredient.png", GL_RGBA, GL_RGBA, 13),//diffuse�������������ͼ
										LoadImageToGPU("container2_specular.png", GL_RGBA, GL_RGBA, 2),//specular�����淴����ͼ
										glm::vec3(1.0f, 1.0f, 1.0f),//ambient
										32.0f);//shininess

	Material* MyMaterial7 = new Material(MyShader7,
										LoadImageToGPU("Pork.png", GL_RGBA, GL_RGBA, 4),//diffuse�������������ͼ
										LoadImageToGPU("container2_specular.png", GL_RGBA, GL_RGBA, 2),//specular�����淴����ͼ
										glm::vec3(1.0f, 1.0f, 1.0f),//ambient
										32.0f);//shininess

	Material* MyMaterial8 = new Material(MyShader8,
										LoadImageToGPU("Correct.jpg", GL_RGB, GL_RGB, 6),//diffuse�������������ͼ
										LoadImageToGPU("container2_specular.png", GL_RGBA, GL_RGBA, 2),//specular�����淴����ͼ
										glm::vec3(1.0f, 1.0f, 1.0f),//ambient
										32.0f);//shininess

	Material* MyMaterial9 = new Material(MyShader9,
										LoadImageToGPU("Broccoli.jpg", GL_RGB, GL_RGB, 8),//diffuse�������������ͼ
										LoadImageToGPU("container2_specular.png", GL_RGBA, GL_RGBA, 2),//specular�����淴����ͼ
										glm::vec3(1.0f, 1.0f, 1.0f),//ambient
										32.0f);//shininess

	Material* MyMaterial10 = new Material(MyShader10,
										LoadImageToGPU("Sauce.png", GL_RGB, GL_RGB, 10),//diffuse�������������ͼ
										LoadImageToGPU("container2_specular.png", GL_RGBA, GL_RGBA, 2),//specular�����淴����ͼ
										glm::vec3(1.0f, 1.0f, 1.0f),//ambient
										32.0f);//shininess
	#pragma endregion

	#pragma region Init and load Models to VAO, VBO

	//Model model0(exePath.substr(0, exePath.find_last_of('\\')) + "\\model\\nanosuit.obj");//�ɴ�
	Model model0(exePath.substr(0, exePath.find_last_of('\\')) + "\\model1\\small_transport_unit_04_03_high.obj");
	Model model1(exePath.substr(0, exePath.find_last_of('\\')) + "\\model2\\Mercury1K.obj");//ԭ������

	Model model2(exePath.substr(0, exePath.find_last_of('\\')) + "\\model2\\Mercury1K.obj");//��ζ����

	Model model3(exePath.substr(0, exePath.find_last_of('\\')) + "\\model2\\Mercury1K.obj");//������

	Model model4(exePath.substr(0, exePath.find_last_of('\\')) + "\\model3\\Moon2K.obj");//����

	Model model5(exePath.substr(0, exePath.find_last_of('\\')) + "\\model2\\Mercury1K.obj");//������
	
	Model model6(exePath.substr(0, exePath.find_last_of('\\')) + "\\model2\\Mercury1K.obj");//������

	Model model7(exePath.substr(0, exePath.find_last_of('\\')) + "\\model3\\Moon2K.obj");//����

	Model model8(exePath.substr(0, exePath.find_last_of('\\')) + "\\model3\\Moon2K.obj");//���ܲ�

	Model model9(exePath.substr(0, exePath.find_last_of('\\')) + "\\model4\\broccoli.obj");//������

	Model model10(exePath.substr(0, exePath.find_last_of('\\')) + "\\model4\\Sauce.obj");//��֭
	#pragma endregion
	
	#pragma region Prepare MVP matrices	
	//�Žǣ�����ߴ磬��ƽ��Զƽ��
	//glm::mat4 trans;//����transform��λ�� ��ת ����˳�������������⻥��Ӱ��

	glm::mat4 modelMat;//ģ��λ�� �ɴ�
	glm::mat4 modelMat1;//ģ��λ�� ʳ������
	glm::mat4 modelMat2;//ģ��λ�� ��ζ����
	glm::mat4 modelMat3;//ģ��λ�� ������
	glm::mat4 modelMat4;//ģ��λ�� ����
	glm::mat4 modelMat5;//ģ��λ�� ������
	glm::mat4 modelMat6;//ģ��λ�� ����
	glm::mat4 modelMat7;//ģ��λ�� ����
	glm::mat4 modelMat8;//ģ��λ�� ���ܲ�
	glm::mat4 modelMat9;//ģ��λ�� ������
	glm::mat4 modelMat10;//ģ��λ�� ��֭
	glm::mat4 viewMat;//�ӽ�λ��
	glm::mat4 projMat;//ͶӰλ��
	projMat = glm::perspective(glm::radians(45.0f), 800.0f / 600.0f, 0.1f, 50000.0f);

	#pragma endregion
	//bool NormalMode=false;
	//bool UpperMode=true;
	bool NormalMode = true;
	bool UpperMode = false;
	/*if (glfwGetKey(MyWindow, GLFW_KEY_V) == GLFW_PRESS) {
		NormalMode = true;
		UpperMode = false;
	}
	else if (glfwGetKey(MyWindow, GLFW_KEY_B) == GLFW_PRESS) {
		UpperMode = true;
		NormalMode = false;
	}*/
	if (NormalMode) {
		while (!glfwWindowShouldClose(MyWindow)) {//��Ⱦѭ��

			viewMat = MyCamera.GetViewMatrix(MyCamera.Position);//�ӽǱ任
			//MyCamera.Position.x = modelposition.x - (5 * MyCamera.Forward.x);
			//MyCamera.Position.y = modelposition.y+2;
			//MyCamera.Position.z = -modelposition.z - (5 * MyCamera.Forward.z);

			//����ǰ��������ƺ���
			processInput(MyWindow);

			//���&���ñ�����ɫ
			glClearColor(0.0f, 0.0f, 0.0f, 1.0f);//RGB��ֵ����͸����1.0
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);//�����ɫ�����

				//������
#pragma region Shader3 set and use, Draw model3
			MyShader3->use();
			modelMat3 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -0.0f, -50.0f));
			modelMat3 = glm::rotate(modelMat3, 0.07f*(float)glfwGetTime(), glm::vec3(0.0f, 1.0f, 0.0f));
			modelMat3 = glm::scale(modelMat3, glm::vec3(1200.0f, 1200.0f, 1200.0f));
			//modelMat1 = glm::rotate(modelMat1, (float)glfwGetTime(), glm::vec3(1.0f, 1.0f, 1.0f));
			glUniformMatrix4fv(glGetUniformLocation(MyShader3->ID, "modelMat"), 1, GL_FALSE, glm::value_ptr(modelMat3));//��uniform��������λ�ƾ���
			glUniformMatrix4fv(glGetUniformLocation(MyShader3->ID, "viewMat"), 1, GL_FALSE, glm::value_ptr(viewMat));//��uniform���������ӽǾ���
			glUniformMatrix4fv(glGetUniformLocation(MyShader3->ID, "projMat"), 1, GL_FALSE, glm::value_ptr(projMat));//��uniform��������ͶӰ����
			glUniform3f(glGetUniformLocation(MyShader3->ID, "ObjColor"), 10.0f, 10.0f, 10.0f);//���ϵ���ɫ
			glUniform3f(glGetUniformLocation(MyShader3->ID, "AmbientColor"), 2.5f, 2.5f, 2.5f);//������
			glUniform3f(glGetUniformLocation(MyShader3->ID, "LightPos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);//��Դλ��
			glUniform3f(glGetUniformLocation(MyShader3->ID, "LightColor"), MyLight.color.x, MyLight.color.y, MyLight.color.z);//��Դ��ɫ
			glUniform3f(glGetUniformLocation(MyShader3->ID, "LightDirUniform"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);//��Դ����

			//ƽ�й�
			glUniform3f(glGetUniformLocation(MyShader3->ID, "lightdirectional.Pos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);
			glUniform3f(glGetUniformLocation(MyShader3->ID, "lightdirectional.DirToLight"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);
			glUniform3f(glGetUniformLocation(MyShader3->ID, "lightdirectional.Color"), MyLight.color.x, MyLight.color.y, MyLight.color.z);
			//���Դ0
			glUniform3f(glGetUniformLocation(MyShader3->ID, "lightpoint0.Pos"), MyLight0.position.x, MyLight0.position.y, MyLight0.position.z);
			glUniform3f(glGetUniformLocation(MyShader3->ID, "lightpoint0.DirToLight"), MyLight0.direction.x, MyLight0.direction.y, MyLight0.direction.z);
			glUniform3f(glGetUniformLocation(MyShader3->ID, "lightpoint0.Color"), MyLight0.color.x, MyLight0.color.y, MyLight0.color.z);
			glUniform1f(glGetUniformLocation(MyShader3->ID, "lightpoint0.constant"), MyLight0.constant);
			glUniform1f(glGetUniformLocation(MyShader3->ID, "lightpoint0.linear"), MyLight0.linear);
			glUniform1f(glGetUniformLocation(MyShader3->ID, "lightpoint0.quadratic"), MyLight0.quadratic);

			//�۹��
			glUniform3f(glGetUniformLocation(MyShader3->ID, "lightspot.Pos"), MyLightSpot.position.x, MyLightSpot.position.y, MyLightSpot.position.z);
			glUniform3f(glGetUniformLocation(MyShader3->ID, "lightspot.DirToLight"), MyLightSpot.direction.x, MyLightSpot.direction.y, MyLightSpot.direction.z);
			glUniform3f(glGetUniformLocation(MyShader3->ID, "lightspot.Color"), MyLightSpot.color.x, MyLightSpot.color.y, MyLightSpot.color.z);
			glUniform1f(glGetUniformLocation(MyShader3->ID, "lightspot.constant"), MyLightSpot.constant);
			glUniform1f(glGetUniformLocation(MyShader3->ID, "lightspot.linear"), MyLightSpot.linear);
			glUniform1f(glGetUniformLocation(MyShader3->ID, "lightspot.quadratic"), MyLightSpot.quadratic);
			glUniform1f(glGetUniformLocation(MyShader3->ID, "lightspot.cosInnerPhy"), MyLightSpot.cosInnerPhy);
			glUniform1f(glGetUniformLocation(MyShader3->ID, "lightspot.cosOutterPhy"), MyLightSpot.cosOutterPhy);

			glUniform3f(glGetUniformLocation(MyShader3->ID, "CameraPos"), MyCamera.Position.x, MyCamera.Position.y, MyCamera.Position.z);//�ӽ�λ�ã�Ӱ�쾵�淴�䣩
			MyMaterial3->shader->SetUniform3f("material.ambient", MyMaterial3->ambient);
			MyMaterial3->shader->SetUniform1i("material.diffuse", 7);
			MyMaterial3->shader->SetUniform1i("material.specular", 2);
			MyMaterial3->shader->SetUniform1f("material.shininess", MyMaterial3->shininess);
			model3.Draw(MyMaterial3->shader);
#pragma endregion

			//�ɴ�
#pragma region Shader0 set and use, Draw model0
			MyShader->use();
			//modelMat = viewMat;					
			//modelMat = glm::translate(glm::mat4(1.0f), glm::vec3(150, 150, 150));
			//modelMat = glm::translate(glm::mat4(1.0f), glm::vec3((modelposition.x *(-MyCamera.Forward.z)+ modelposition.z*(MyCamera.Forward.x)), 
			//													modelposition.y, 
			//													(modelposition.x*(1+MyCamera.Forward.z)- modelposition.z*(1-MyCamera.Forward.x))));
			modelMat = glm::translate(glm::mat4(1.0f), glm::vec3(MyCamera.Position.x + (5 * MyCamera.Forward.x), MyCamera.Position.y - 2.0f + (5 * MyCamera.Forward.y), MyCamera.Position.z + (7 * MyCamera.Forward.z)));
			//modelMat = glm::rotate(modelMat, glm::radians(180.0f), glm::vec3(0.0f, 1.0f, 0.0f));
			if (MyCamera.Forward.z <= 0) { modelMat = glm::rotate(modelMat, -1.0f*MyCamera.Forward.x, glm::vec3(0.0f, 1.0f, 0.0f)); }
			else if (MyCamera.Forward.z > 0) { modelMat = glm::rotate(modelMat, 1.0f*MyCamera.Forward.x + glm::radians(180.0f), glm::vec3(0.0f, 1.0f, 0.0f)); }
			//modelMat = glm::rotate(modelMat, 1.4f*MyCamera.Forward.y, glm::vec3(1.0f, 0.0f, 0.0f));
			modelMat = glm::rotate(modelMat, glm::radians(270.0f), glm::vec3(0.0f, 1.0f, 0.0f));
			//modelMat = glm::rotate(modelMat, glm::radians(45.0f), glm::vec3(1.0f, 0.0f, 0.0f));
			modelMat = glm::scale(modelMat, glm::vec3(0.01f, 0.01f, 0.01f));
			MyLightSpot.position = glm::vec3(MyCamera.Position.x + (5 * MyCamera.Forward.x), MyCamera.Position.y - 2 + (5 * MyCamera.Forward.y), MyCamera.Position.z + (7 * MyCamera.Forward.z));
			//MyLightSpot.position = MyCamera.Position;
			MyLightSpot.direction = -MyCamera.Forward;
			glUniformMatrix4fv(glGetUniformLocation(MyShader->ID, "modelMat"), 1, GL_FALSE, glm::value_ptr(modelMat));//��uniform��������λ�ƾ���
			glUniformMatrix4fv(glGetUniformLocation(MyShader->ID, "viewMat"), 1, GL_FALSE, glm::value_ptr(viewMat));//��uniform���������ӽǾ���
			glUniformMatrix4fv(glGetUniformLocation(MyShader->ID, "projMat"), 1, GL_FALSE, glm::value_ptr(projMat));//��uniform��������ͶӰ����
			glUniform3f(glGetUniformLocation(MyShader->ID, "ObjColor"), 1.0f, 1.0f, 1.0f);//���ϵ���ɫ
			glUniform3f(glGetUniformLocation(MyShader->ID, "AmbientColor"), 2.0f, 2.0f, 2.0f);//������

			//��Ϸ�ж�
			float distance = 20;

			//��������
			if (glm::abs(MyCamera.Position.x - ((120 * sin(0.5f*(float)glfwGetTime())) + (500 * sin(-0.05f*(float)glfwGetTime())))) <= distance &&glm::abs(MyCamera.Position.y-0)<=distance&& glm::abs(MyCamera.Position.z - (-50 + 120 * cos(0.5f*(float)glfwGetTime()) + 500 * cos(-0.05f*(float)glfwGetTime()))) <= distance) {
				glUniform3f(glGetUniformLocation(MyShader->ID, "AmbientColor"), 2.0f, 0.0f, 0.0f);//���
				if (pork&&carrot&&broccoli&&sauce) { std::cout << "YOU CAN MAKE THE BBQ PORK NOW!!! RETURN TO THE EARTH!!!" << endl; }
				else { std::cout << "GET PORK!!!" << endl; }
				pork=true;
			}
			//������ܲ�
			if (glm::abs(MyCamera.Position.x - ((110 * sin(-0.3f*(float)glfwGetTime())) + (500 * sin(-0.05f*(float)glfwGetTime())))) <= distance && glm::abs(MyCamera.Position.y - 40) <= distance && glm::abs(MyCamera.Position.z - (-50 + 110 * cos(-0.3f*(float)glfwGetTime()) + 500 * cos(-0.05f*(float)glfwGetTime()))) <= distance) {
				glUniform3f(glGetUniformLocation(MyShader->ID, "AmbientColor"), 0.0f, 0.0f, 2.0f);//����
				if (pork&&carrot&&broccoli&&sauce) { std::cout << "YOU CAN MAKE THE BBQ PORK NOW!!! RETURN TO THE EARTH!!!" << endl; }
				else { std::cout << "GET CORROT!!!" << endl; }
				carrot = true;
			}
			//����������
			if (glm::abs(MyCamera.Position.x - ((110 * sin(-0.8f*(float)glfwGetTime())) + (500 * sin(-0.05f*(float)glfwGetTime())))) <= distance && glm::abs(MyCamera.Position.y + 40) <= distance && glm::abs(MyCamera.Position.z - (-50 + 110 * cos(-0.8f*(float)glfwGetTime()) + 500 * cos(-0.05f*(float)glfwGetTime()))) <= distance) {
				glUniform3f(glGetUniformLocation(MyShader->ID, "AmbientColor"), 0.0f, 2.0f, 0.0f);//����
				if (pork&&carrot&&broccoli&&sauce) { std::cout << "YOU CAN MAKE THE BBQ PORK NOW!!! RETURN TO THE EARTH!!!" << endl; }
				else { std::cout << "GET BROCCOLI!!!" << endl; }
				broccoli = true;
			}
			//����֭
			if (glm::abs(MyCamera.Position.x - ((110 * sin(-0.2f*(float)glfwGetTime())) + (760 * sin(0.25f*(float)glfwGetTime())))) <= distance && glm::abs(MyCamera.Position.y - 0) <= distance && glm::abs(MyCamera.Position.z - (-50 + 110 * cos(-0.2f*(float)glfwGetTime()) + 760 * cos(0.25f*(float)glfwGetTime()))) <= distance) {
				glUniform3f(glGetUniformLocation(MyShader->ID, "AmbientColor"), 0.0f, 0.0f, 0.0f);//����ɫ
				if (pork&&carrot&&broccoli&&sauce) { std::cout << "YOU CAN MAKE THE BBQ PORK NOW!!! RETURN TO THE EARTH!!!" << endl; }
				else { std::cout << "GET SAUCE!!!" << endl; }
				sauce = true;
			}
			//�ص�����
			if (glm::abs(MyCamera.Position.x - (1200 * sin(0.1f*(float)glfwGetTime()))) <= 100 && glm::abs(MyCamera.Position.y - 0) <= 100 && glm::abs(MyCamera.Position.z - (-50 + 1200 * cos(0.1f*(float)glfwGetTime()))) <= 100) {
				if (pork&&carrot&&broccoli&&sauce) {
					std::cout << "THANK YOU FOR YOUR BBQ PORK!!!EARTHMEN APPRECIATE YOU!!!" << endl;				
				}
				else {
					std::cout << "YOU NEED CONTINUE FINDING THE BBQ PORK MATERIALS!!!" << endl;
				}
			}
			glUniform3f(glGetUniformLocation(MyShader->ID, "LightPos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);//��Դλ��
			glUniform3f(glGetUniformLocation(MyShader->ID, "LightColor"), MyLight.color.x, MyLight.color.y, MyLight.color.z);//��Դ��ɫ
			glUniform3f(glGetUniformLocation(MyShader->ID, "LightDirUniform"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);//��Դ����

			//ƽ�й�
			glUniform3f(glGetUniformLocation(MyShader->ID, "lightdirectional.Pos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);
			glUniform3f(glGetUniformLocation(MyShader->ID, "lightdirectional.DirToLight"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);
			glUniform3f(glGetUniformLocation(MyShader->ID, "lightdirectional.Color"), MyLight.color.x, MyLight.color.y, MyLight.color.z);
			//���Դ0
			glUniform3f(glGetUniformLocation(MyShader->ID, "lightpoint0.Pos"), MyLight0.position.x, MyLight0.position.y, MyLight0.position.z);
			glUniform3f(glGetUniformLocation(MyShader->ID, "lightpoint0.DirToLight"), MyLight0.direction.x, MyLight0.direction.y, MyLight0.direction.z);
			glUniform3f(glGetUniformLocation(MyShader->ID, "lightpoint0.Color"), MyLight0.color.x, MyLight0.color.y, MyLight0.color.z);
			glUniform1f(glGetUniformLocation(MyShader->ID, "lightpoint0.constant"), MyLight0.constant);
			glUniform1f(glGetUniformLocation(MyShader->ID, "lightpoint0.linear"), MyLight0.linear);
			glUniform1f(glGetUniformLocation(MyShader->ID, "lightpoint0.quadratic"), MyLight0.quadratic);

			//�۹��
			glUniform3f(glGetUniformLocation(MyShader->ID, "lightspot.Pos"), MyLightSpot.position.x, MyLightSpot.position.y, MyLightSpot.position.z);
			glUniform3f(glGetUniformLocation(MyShader->ID, "lightspot.DirToLight"), MyLightSpot.direction.x, MyLightSpot.direction.y, MyLightSpot.direction.z);
			glUniform3f(glGetUniformLocation(MyShader->ID, "lightspot.Color"), 0.1f*MyLightSpot.color.x, 0.1f*MyLightSpot.color.y, 0.1f*MyLightSpot.color.z);
			glUniform1f(glGetUniformLocation(MyShader->ID, "lightspot.constant"), MyLightSpot.constant);
			glUniform1f(glGetUniformLocation(MyShader->ID, "lightspot.linear"), MyLightSpot.linear);
			glUniform1f(glGetUniformLocation(MyShader->ID, "lightspot.quadratic"), MyLightSpot.quadratic);
			glUniform1f(glGetUniformLocation(MyShader->ID, "lightspot.cosInnerPhy"), MyLightSpot.cosInnerPhy);
			glUniform1f(glGetUniformLocation(MyShader->ID, "lightspot.cosOutterPhy"), MyLightSpot.cosOutterPhy);

			glUniform3f(glGetUniformLocation(MyShader->ID, "CameraPos"), MyCamera.Position.x, MyCamera.Position.y, MyCamera.Position.z);//�ӽ�λ�ã�Ӱ�쾵�淴�䣩
			MyMaterial->shader->SetUniform3f("material.ambient", MyMaterial->ambient);
			MyMaterial->shader->SetUniform1i("material.diffuse", 1);
			MyMaterial->shader->SetUniform1i("material.specular", 2);
			MyMaterial->shader->SetUniform1f("material.shininess", MyMaterial->shininess);
			model0.Draw(MyMaterial->shader);
#pragma endregion		

			//ԭ������
#pragma region Shader1 set and use, Draw model1
			MyShader1->use();
			modelMat1 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -10.0f, 0.0f));
			modelMat1 = glm::translate(modelMat1, glm::vec3((500 * sin(-0.05f*(float)glfwGetTime())), 0.0f, -50 + 500 * cos(-0.05f*(float)glfwGetTime())));
			modelMat1 = glm::rotate(modelMat1, -0.6f*(float)glfwGetTime(), glm::vec3(0.0f, 1.0f, 0.0f));
			modelMat1 = glm::scale(modelMat1, glm::vec3(400.0f, 400.0f, 400.0f));
			glUniformMatrix4fv(glGetUniformLocation(MyShader1->ID, "modelMat"), 1, GL_FALSE, glm::value_ptr(modelMat1));//��uniform��������λ�ƾ���
			glUniformMatrix4fv(glGetUniformLocation(MyShader1->ID, "viewMat"), 1, GL_FALSE, glm::value_ptr(viewMat));//��uniform���������ӽǾ���
			glUniformMatrix4fv(glGetUniformLocation(MyShader1->ID, "projMat"), 1, GL_FALSE, glm::value_ptr(projMat));//��uniform��������ͶӰ����
			glUniform3f(glGetUniformLocation(MyShader1->ID, "ObjColor"), 1.0f, 1.0f, 1.0f);//���ϵ���ɫ
			glUniform3f(glGetUniformLocation(MyShader1->ID, "AmbientColor"), 1.0f, 1.0f, 1.0f);//������
			glUniform3f(glGetUniformLocation(MyShader1->ID, "LightPos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);//��Դλ��
			glUniform3f(glGetUniformLocation(MyShader1->ID, "LightColor"), MyLight.color.x, MyLight.color.y, MyLight.color.z);//��Դ��ɫ
			glUniform3f(glGetUniformLocation(MyShader1->ID, "LightDirUniform"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);//��Դ����

			//ƽ�й�
			glUniform3f(glGetUniformLocation(MyShader1->ID, "lightdirectional.Pos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);
			glUniform3f(glGetUniformLocation(MyShader1->ID, "lightdirectional.DirToLight"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);
			glUniform3f(glGetUniformLocation(MyShader1->ID, "lightdirectional.Color"), MyLight.color.x, MyLight.color.y, MyLight.color.z);
			//���Դ0
			glUniform3f(glGetUniformLocation(MyShader1->ID, "lightpoint0.Pos"), MyLight0.position.x, MyLight0.position.y, MyLight0.position.z);
			glUniform3f(glGetUniformLocation(MyShader1->ID, "lightpoint0.DirToLight"), MyLight0.direction.x, MyLight0.direction.y, MyLight0.direction.z);
			glUniform3f(glGetUniformLocation(MyShader1->ID, "lightpoint0.Color"), MyLight0.color.x, MyLight0.color.y, MyLight0.color.z);
			glUniform1f(glGetUniformLocation(MyShader1->ID, "lightpoint0.constant"), MyLight0.constant);
			glUniform1f(glGetUniformLocation(MyShader1->ID, "lightpoint0.linear"), MyLight0.linear);
			glUniform1f(glGetUniformLocation(MyShader1->ID, "lightpoint0.quadratic"), MyLight0.quadratic);

			//�۹��
			glUniform3f(glGetUniformLocation(MyShader1->ID, "lightspot.Pos"), MyLightSpot.position.x, MyLightSpot.position.y, MyLightSpot.position.z);
			glUniform3f(glGetUniformLocation(MyShader1->ID, "lightspot.DirToLight"), MyLightSpot.direction.x, MyLightSpot.direction.y, MyLightSpot.direction.z);
			glUniform3f(glGetUniformLocation(MyShader1->ID, "lightspot.Color"), MyLightSpot.color.x, MyLightSpot.color.y, MyLightSpot.color.z);
			glUniform1f(glGetUniformLocation(MyShader1->ID, "lightspot.constant"), MyLightSpot.constant);
			glUniform1f(glGetUniformLocation(MyShader1->ID, "lightspot.linear"), MyLightSpot.linear);
			glUniform1f(glGetUniformLocation(MyShader1->ID, "lightspot.quadratic"), MyLightSpot.quadratic);
			glUniform1f(glGetUniformLocation(MyShader1->ID, "lightspot.cosInnerPhy"), MyLightSpot.cosInnerPhy);
			glUniform1f(glGetUniformLocation(MyShader1->ID, "lightspot.cosOutterPhy"), MyLightSpot.cosOutterPhy);

			glUniform3f(glGetUniformLocation(MyShader1->ID, "CameraPos"), MyCamera.Position.x, MyCamera.Position.y, MyCamera.Position.z);//�ӽ�λ�ã�Ӱ�쾵�淴�䣩
			MyMaterial1->shader->SetUniform3f("material.ambient", MyMaterial1->ambient);
			MyMaterial1->shader->SetUniform1i("material.diffuse", 3);
			MyMaterial1->shader->SetUniform1i("material.specular", 2);
			MyMaterial1->shader->SetUniform1f("material.shininess", MyMaterial1->shininess);
			model1.Draw(MyMaterial1->shader);
#pragma endregion

			//������
#pragma region Shader2 set and use, Draw model2
			MyShader2->use();
			modelMat2 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -10.0f, 0.0f));
			modelMat2 = glm::translate(modelMat2, glm::vec3((1200 * sin(0.1f*(float)glfwGetTime())), 0.0f, -50 + 1200 * cos(0.1f*(float)glfwGetTime())));
			modelMat2 = glm::scale(modelMat2, glm::vec3(360.0f, 360.0f, 360.0f));
			modelMat2 = glm::rotate(modelMat2, 0.6f*(float)glfwGetTime(), glm::vec3(0.0f, 1.0f, 0.0f));
			//modelMat1 = glm::rotate(modelMat1, (float)glfwGetTime(), glm::vec3(1.0f, 1.0f, 1.0f));
			glUniformMatrix4fv(glGetUniformLocation(MyShader2->ID, "modelMat"), 1, GL_FALSE, glm::value_ptr(modelMat2));//��uniform��������λ�ƾ���
			glUniformMatrix4fv(glGetUniformLocation(MyShader2->ID, "viewMat"), 1, GL_FALSE, glm::value_ptr(viewMat));//��uniform���������ӽǾ���
			glUniformMatrix4fv(glGetUniformLocation(MyShader2->ID, "projMat"), 1, GL_FALSE, glm::value_ptr(projMat));//��uniform��������ͶӰ����
			glUniform3f(glGetUniformLocation(MyShader2->ID, "ObjColor"), 1.0f, 1.0f, 1.0f);//���ϵ���ɫ
			glUniform3f(glGetUniformLocation(MyShader2->ID, "AmbientColor"), 1.0f, 1.0f, 1.0f);//������
			glUniform3f(glGetUniformLocation(MyShader2->ID, "LightPos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);//��Դλ��
			glUniform3f(glGetUniformLocation(MyShader2->ID, "LightColor"), MyLight.color.x, MyLight.color.y, MyLight.color.z);//��Դ��ɫ
			glUniform3f(glGetUniformLocation(MyShader2->ID, "LightDirUniform"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);//��Դ����

			//ƽ�й�
			glUniform3f(glGetUniformLocation(MyShader2->ID, "lightdirectional.Pos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);
			glUniform3f(glGetUniformLocation(MyShader2->ID, "lightdirectional.DirToLight"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);
			glUniform3f(glGetUniformLocation(MyShader2->ID, "lightdirectional.Color"), MyLight.color.x, MyLight.color.y, MyLight.color.z);
			//���Դ0
			glUniform3f(glGetUniformLocation(MyShader2->ID, "lightpoint0.Pos"), MyLight0.position.x, MyLight0.position.y, MyLight0.position.z);
			glUniform3f(glGetUniformLocation(MyShader2->ID, "lightpoint0.DirToLight"), MyLight0.direction.x, MyLight0.direction.y, MyLight0.direction.z);
			glUniform3f(glGetUniformLocation(MyShader2->ID, "lightpoint0.Color"), MyLight0.color.x, MyLight0.color.y, MyLight0.color.z);
			glUniform1f(glGetUniformLocation(MyShader2->ID, "lightpoint0.constant"), MyLight0.constant);
			glUniform1f(glGetUniformLocation(MyShader2->ID, "lightpoint0.linear"), MyLight0.linear);
			glUniform1f(glGetUniformLocation(MyShader2->ID, "lightpoint0.quadratic"), MyLight0.quadratic);

			//�۹��
			glUniform3f(glGetUniformLocation(MyShader2->ID, "lightspot.Pos"), MyLightSpot.position.x, MyLightSpot.position.y, MyLightSpot.position.z);
			glUniform3f(glGetUniformLocation(MyShader2->ID, "lightspot.DirToLight"), MyLightSpot.direction.x, MyLightSpot.direction.y, MyLightSpot.direction.z);
			glUniform3f(glGetUniformLocation(MyShader2->ID, "lightspot.Color"), MyLightSpot.color.x, MyLightSpot.color.y, MyLightSpot.color.z);
			glUniform1f(glGetUniformLocation(MyShader2->ID, "lightspot.constant"), MyLightSpot.constant);
			glUniform1f(glGetUniformLocation(MyShader2->ID, "lightspot.linear"), MyLightSpot.linear);
			glUniform1f(glGetUniformLocation(MyShader2->ID, "lightspot.quadratic"), MyLightSpot.quadratic);
			glUniform1f(glGetUniformLocation(MyShader2->ID, "lightspot.cosInnerPhy"), MyLightSpot.cosInnerPhy);
			glUniform1f(glGetUniformLocation(MyShader2->ID, "lightspot.cosOutterPhy"), MyLightSpot.cosOutterPhy);

			glUniform3f(glGetUniformLocation(MyShader2->ID, "CameraPos"), MyCamera.Position.x, MyCamera.Position.y, MyCamera.Position.z);//�ӽ�λ�ã�Ӱ�쾵�淴�䣩
			MyMaterial2->shader->SetUniform3f("material.ambient", MyMaterial2->ambient);
			MyMaterial2->shader->SetUniform1i("material.diffuse", 5);
			MyMaterial2->shader->SetUniform1i("material.specular", 2);
			MyMaterial2->shader->SetUniform1f("material.shininess", MyMaterial2->shininess);
			model2.Draw(MyMaterial2->shader);
#pragma endregion

			//����
#pragma region Shader4 set and use, Draw model4
			MyShader4->use();
			//modelMat4 = glm::translate(glm::mat4(1.0f), glm::vec3(60.0f, 0.0f, 5.0f));

			modelMat4 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -10.0f, 0.0f));
			//modelMat2 = glm::translate(modelMat2, glm::vec3((30 * sin(0.3f*(float)glfwGetTime())), 0.0f, -50 + 30 * cos(0.3f*(float)glfwGetTime())));
			modelMat4 = glm::translate(modelMat4, glm::vec3((120 * sin(1.5f*(float)glfwGetTime())) + (1200 * sin(0.1f*(float)glfwGetTime())), 0.0f, -50 + 120 * cos(1.5f*(float)glfwGetTime()) + 1200 * cos(0.1f*(float)glfwGetTime())));

			modelMat4 = glm::scale(modelMat4, glm::vec3(12.0f, 12.0f, 12.0f));
			modelMat4 = glm::rotate(modelMat4, -0.8f*(float)glfwGetTime(), glm::vec3(0.0f, 1.0f, 0.0f));
			//modelMat1 = glm::rotate(modelMat1, (float)glfwGetTime(), glm::vec3(1.0f, 1.0f, 1.0f));
			glUniformMatrix4fv(glGetUniformLocation(MyShader4->ID, "modelMat"), 1, GL_FALSE, glm::value_ptr(modelMat4));//��uniform��������λ�ƾ���
			glUniformMatrix4fv(glGetUniformLocation(MyShader4->ID, "viewMat"), 1, GL_FALSE, glm::value_ptr(viewMat));//��uniform���������ӽǾ���
			glUniformMatrix4fv(glGetUniformLocation(MyShader4->ID, "projMat"), 1, GL_FALSE, glm::value_ptr(projMat));//��uniform��������ͶӰ����
			glUniform3f(glGetUniformLocation(MyShader4->ID, "ObjColor"), 1.0f, 1.0f, 1.0f);//���ϵ���ɫ
			glUniform3f(glGetUniformLocation(MyShader4->ID, "AmbientColor"), 1.0f, 1.0f, 1.0f);//������
			glUniform3f(glGetUniformLocation(MyShader4->ID, "LightPos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);//��Դλ��
			glUniform3f(glGetUniformLocation(MyShader4->ID, "LightColor"), MyLight.color.x, MyLight.color.y, MyLight.color.z);//��Դ��ɫ
			glUniform3f(glGetUniformLocation(MyShader4->ID, "LightDirUniform"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);//��Դ����

			//ƽ�й�
			glUniform3f(glGetUniformLocation(MyShader4->ID, "lightdirectional.Pos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);
			glUniform3f(glGetUniformLocation(MyShader4->ID, "lightdirectional.DirToLight"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);
			glUniform3f(glGetUniformLocation(MyShader4->ID, "lightdirectional.Color"), MyLight.color.x, MyLight.color.y, MyLight.color.z);
			//���Դ0
			glUniform3f(glGetUniformLocation(MyShader4->ID, "lightpoint0.Pos"), MyLight0.position.x, MyLight0.position.y, MyLight0.position.z);
			glUniform3f(glGetUniformLocation(MyShader4->ID, "lightpoint0.DirToLight"), MyLight0.direction.x, MyLight0.direction.y, MyLight0.direction.z);
			glUniform3f(glGetUniformLocation(MyShader4->ID, "lightpoint0.Color"), MyLight0.color.x, MyLight0.color.y, MyLight0.color.z);
			glUniform1f(glGetUniformLocation(MyShader4->ID, "lightpoint0.constant"), MyLight0.constant);
			glUniform1f(glGetUniformLocation(MyShader4->ID, "lightpoint0.linear"), MyLight0.linear);
			glUniform1f(glGetUniformLocation(MyShader4->ID, "lightpoint0.quadratic"), MyLight0.quadratic);

			//�۹��
			glUniform3f(glGetUniformLocation(MyShader4->ID, "lightspot.Pos"), MyLightSpot.position.x, MyLightSpot.position.y, MyLightSpot.position.z);
			glUniform3f(glGetUniformLocation(MyShader4->ID, "lightspot.DirToLight"), MyLightSpot.direction.x, MyLightSpot.direction.y, MyLightSpot.direction.z);
			glUniform3f(glGetUniformLocation(MyShader4->ID, "lightspot.Color"), MyLightSpot.color.x, MyLightSpot.color.y, MyLightSpot.color.z);
			glUniform1f(glGetUniformLocation(MyShader4->ID, "lightspot.constant"), MyLightSpot.constant);
			glUniform1f(glGetUniformLocation(MyShader4->ID, "lightspot.linear"), MyLightSpot.linear);
			glUniform1f(glGetUniformLocation(MyShader4->ID, "lightspot.quadratic"), MyLightSpot.quadratic);
			glUniform1f(glGetUniformLocation(MyShader4->ID, "lightspot.cosInnerPhy"), MyLightSpot.cosInnerPhy);
			glUniform1f(glGetUniformLocation(MyShader4->ID, "lightspot.cosOutterPhy"), MyLightSpot.cosOutterPhy);

			glUniform3f(glGetUniformLocation(MyShader4->ID, "CameraPos"), MyCamera.Position.x, MyCamera.Position.y, MyCamera.Position.z);//�ӽ�λ�ã�Ӱ�쾵�淴�䣩
			MyMaterial4->shader->SetUniform3f("material.ambient", MyMaterial3->ambient);
			MyMaterial4->shader->SetUniform1i("material.diffuse", 9);
			MyMaterial4->shader->SetUniform1i("material.specular", 2);
			MyMaterial4->shader->SetUniform1f("material.shininess", MyMaterial3->shininess);
			model4.Draw(MyMaterial4->shader);
#pragma endregion

			//������
#pragma region Shader5 set and use, Draw model5
			MyShader5->use();
			modelMat5 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -10.0f, -50.0f));
			modelMat5 = glm::rotate(modelMat5, 0.01f*(float)glfwGetTime(), glm::vec3(0.0f, 1.0f, 0.0f));
			modelMat5 = glm::scale(modelMat5, glm::vec3(10000.0f, 10000.0f, 10000.0f));
			//modelMat1 = glm::rotate(modelMat1, (float)glfwGetTime(), glm::vec3(1.0f, 1.0f, 1.0f));
			glUniformMatrix4fv(glGetUniformLocation(MyShader5->ID, "modelMat"), 1, GL_FALSE, glm::value_ptr(modelMat5));//��uniform��������λ�ƾ���
			glUniformMatrix4fv(glGetUniformLocation(MyShader5->ID, "viewMat"), 1, GL_FALSE, glm::value_ptr(viewMat));//��uniform���������ӽǾ���
			glUniformMatrix4fv(glGetUniformLocation(MyShader5->ID, "projMat"), 1, GL_FALSE, glm::value_ptr(projMat));//��uniform��������ͶӰ����
			glUniform3f(glGetUniformLocation(MyShader5->ID, "ObjColor"), 10.0f, 10.0f, 10.0f);//���ϵ���ɫ
			glUniform3f(glGetUniformLocation(MyShader5->ID, "AmbientColor"), 3.0f, 3.0f, 3.0f);//������
			glUniform3f(glGetUniformLocation(MyShader5->ID, "LightPos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);//��Դλ��
			glUniform3f(glGetUniformLocation(MyShader5->ID, "LightColor"), MyLight.color.x, MyLight.color.y, MyLight.color.z);//��Դ��ɫ
			glUniform3f(glGetUniformLocation(MyShader5->ID, "LightDirUniform"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);//��Դ����

			//ƽ�й�
			glUniform3f(glGetUniformLocation(MyShader5->ID, "lightdirectional.Pos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);
			glUniform3f(glGetUniformLocation(MyShader5->ID, "lightdirectional.DirToLight"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);
			glUniform3f(glGetUniformLocation(MyShader5->ID, "lightdirectional.Color"), MyLight.color.x, MyLight.color.y, MyLight.color.z);
			//���Դ0
			glUniform3f(glGetUniformLocation(MyShader5->ID, "lightpoint0.Pos"), MyLight0.position.x, MyLight0.position.y, MyLight0.position.z);
			glUniform3f(glGetUniformLocation(MyShader5->ID, "lightpoint0.DirToLight"), MyLight0.direction.x, MyLight0.direction.y, MyLight0.direction.z);
			glUniform3f(glGetUniformLocation(MyShader5->ID, "lightpoint0.Color"), MyLight0.color.x, MyLight0.color.y, MyLight0.color.z);
			glUniform1f(glGetUniformLocation(MyShader5->ID, "lightpoint0.constant"), MyLight0.constant);
			glUniform1f(glGetUniformLocation(MyShader5->ID, "lightpoint0.linear"), MyLight0.linear);
			glUniform1f(glGetUniformLocation(MyShader5->ID, "lightpoint0.quadratic"), MyLight0.quadratic);

			//�۹��
			glUniform3f(glGetUniformLocation(MyShader5->ID, "lightspot.Pos"), MyLightSpot.position.x, MyLightSpot.position.y, MyLightSpot.position.z);
			glUniform3f(glGetUniformLocation(MyShader5->ID, "lightspot.DirToLight"), MyLightSpot.direction.x, MyLightSpot.direction.y, MyLightSpot.direction.z);
			glUniform3f(glGetUniformLocation(MyShader5->ID, "lightspot.Color"), MyLightSpot.color.x, MyLightSpot.color.y, MyLightSpot.color.z);
			glUniform1f(glGetUniformLocation(MyShader5->ID, "lightspot.constant"), MyLightSpot.constant);
			glUniform1f(glGetUniformLocation(MyShader5->ID, "lightspot.linear"), MyLightSpot.linear);
			glUniform1f(glGetUniformLocation(MyShader5->ID, "lightspot.quadratic"), MyLightSpot.quadratic);
			glUniform1f(glGetUniformLocation(MyShader5->ID, "lightspot.cosInnerPhy"), MyLightSpot.cosInnerPhy);
			glUniform1f(glGetUniformLocation(MyShader5->ID, "lightspot.cosOutterPhy"), MyLightSpot.cosOutterPhy);

			glUniform3f(glGetUniformLocation(MyShader5->ID, "CameraPos"), MyCamera.Position.x, MyCamera.Position.y, MyCamera.Position.z);//�ӽ�λ�ã�Ӱ�쾵�淴�䣩
			MyMaterial5->shader->SetUniform3f("material.ambient", MyMaterial5->ambient);
			MyMaterial5->shader->SetUniform1i("material.diffuse", 11);
			MyMaterial5->shader->SetUniform1i("material.specular", 2);
			MyMaterial5->shader->SetUniform1f("material.shininess", MyMaterial5->shininess);
			model5.Draw(MyMaterial5->shader);
#pragma endregion

			//������
#pragma region Shader6 set and use, Draw model6
			MyShader6->use();
			modelMat6 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -10.0f, 0.0f));
			modelMat6 = glm::translate(modelMat6, glm::vec3((760 * sin(0.25f*(float)glfwGetTime())), 0.0f, -50 + 760 * cos(0.25f*(float)glfwGetTime())));
			modelMat6 = glm::scale(modelMat6, glm::vec3(300.0f, 300.0f, 300.0f));
			modelMat6 = glm::rotate(modelMat6, 0.6f*(float)glfwGetTime(), glm::vec3(0.0f, 1.0f, 0.0f));
			//modelMat1 = glm::rotate(modelMat1, (float)glfwGetTime(), glm::vec3(1.0f, 1.0f, 1.0f));
			glUniformMatrix4fv(glGetUniformLocation(MyShader6->ID, "modelMat"), 1, GL_FALSE, glm::value_ptr(modelMat6));//��uniform��������λ�ƾ���
			glUniformMatrix4fv(glGetUniformLocation(MyShader6->ID, "viewMat"), 1, GL_FALSE, glm::value_ptr(viewMat));//��uniform���������ӽǾ���
			glUniformMatrix4fv(glGetUniformLocation(MyShader6->ID, "projMat"), 1, GL_FALSE, glm::value_ptr(projMat));//��uniform��������ͶӰ����
			glUniform3f(glGetUniformLocation(MyShader6->ID, "ObjColor"), 1.0f, 1.0f, 1.0f);//���ϵ���ɫ
			glUniform3f(glGetUniformLocation(MyShader6->ID, "AmbientColor"), 1.0f, 1.0f, 1.0f);//������
			glUniform3f(glGetUniformLocation(MyShader6->ID, "LightPos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);//��Դλ��
			glUniform3f(glGetUniformLocation(MyShader6->ID, "LightColor"), MyLight.color.x, MyLight.color.y, MyLight.color.z);//��Դ��ɫ
			glUniform3f(glGetUniformLocation(MyShader6->ID, "LightDirUniform"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);//��Դ����

			//ƽ�й�
			glUniform3f(glGetUniformLocation(MyShader6->ID, "lightdirectional.Pos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);
			glUniform3f(glGetUniformLocation(MyShader6->ID, "lightdirectional.DirToLight"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);
			glUniform3f(glGetUniformLocation(MyShader6->ID, "lightdirectional.Color"), MyLight.color.x, MyLight.color.y, MyLight.color.z);
			//���Դ0
			glUniform3f(glGetUniformLocation(MyShader6->ID, "lightpoint0.Pos"), MyLight0.position.x, MyLight0.position.y, MyLight0.position.z);
			glUniform3f(glGetUniformLocation(MyShader6->ID, "lightpoint0.DirToLight"), MyLight0.direction.x, MyLight0.direction.y, MyLight0.direction.z);
			glUniform3f(glGetUniformLocation(MyShader6->ID, "lightpoint0.Color"), MyLight0.color.x, MyLight0.color.y, MyLight0.color.z);
			glUniform1f(glGetUniformLocation(MyShader6->ID, "lightpoint0.constant"), MyLight0.constant);
			glUniform1f(glGetUniformLocation(MyShader6->ID, "lightpoint0.linear"), MyLight0.linear);
			glUniform1f(glGetUniformLocation(MyShader6->ID, "lightpoint0.quadratic"), MyLight0.quadratic);

			//�۹��
			glUniform3f(glGetUniformLocation(MyShader6->ID, "lightspot.Pos"), MyLightSpot.position.x, MyLightSpot.position.y, MyLightSpot.position.z);
			glUniform3f(glGetUniformLocation(MyShader6->ID, "lightspot.DirToLight"), MyLightSpot.direction.x, MyLightSpot.direction.y, MyLightSpot.direction.z);
			glUniform3f(glGetUniformLocation(MyShader6->ID, "lightspot.Color"), MyLightSpot.color.x, MyLightSpot.color.y, MyLightSpot.color.z);
			glUniform1f(glGetUniformLocation(MyShader6->ID, "lightspot.constant"), MyLightSpot.constant);
			glUniform1f(glGetUniformLocation(MyShader6->ID, "lightspot.linear"), MyLightSpot.linear);
			glUniform1f(glGetUniformLocation(MyShader6->ID, "lightspot.quadratic"), MyLightSpot.quadratic);
			glUniform1f(glGetUniformLocation(MyShader6->ID, "lightspot.cosInnerPhy"), MyLightSpot.cosInnerPhy);
			glUniform1f(glGetUniformLocation(MyShader6->ID, "lightspot.cosOutterPhy"), MyLightSpot.cosOutterPhy);

			glUniform3f(glGetUniformLocation(MyShader6->ID, "CameraPos"), MyCamera.Position.x, MyCamera.Position.y, MyCamera.Position.z);//�ӽ�λ�ã�Ӱ�쾵�淴�䣩
			MyMaterial6->shader->SetUniform3f("material.ambient", MyMaterial6->ambient);
			MyMaterial6->shader->SetUniform1i("material.diffuse", 13);
			MyMaterial6->shader->SetUniform1i("material.specular", 2);
			MyMaterial6->shader->SetUniform1f("material.shininess", MyMaterial6->shininess);
			model6.Draw(MyMaterial6->shader);
#pragma endregion

			//����
#pragma region Shader7 set and use, Draw model7
			MyShader7->use();
			//modelMat4 = glm::translate(glm::mat4(1.0f), glm::vec3(60.0f, 0.0f, 5.0f));

			modelMat7 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -10.0f, 0.0f));
			//modelMat1 = glm::translate(modelMat1, glm::vec3((500 * sin(-0.05f*(float)glfwGetTime())), 0.0f, -50 + 500 * cos(-0.05f*(float)glfwGetTime())));
			modelMat7 = glm::translate(modelMat7, glm::vec3((120 * sin(0.5f*(float)glfwGetTime())) + (500 * sin(-0.05f*(float)glfwGetTime())), 0.0f, -50 + 120 * cos(0.5f*(float)glfwGetTime()) + 500 * cos(-0.05f*(float)glfwGetTime())));

			modelMat7 = glm::scale(modelMat7, glm::vec3(12.0f, 12.0f, 12.0f));
			modelMat7 = glm::rotate(modelMat7, -0.8f*(float)glfwGetTime(), glm::vec3(0.0f, 1.0f, 0.0f));
			//modelMat1 = glm::rotate(modelMat1, (float)glfwGetTime(), glm::vec3(1.0f, 1.0f, 1.0f));
			glUniformMatrix4fv(glGetUniformLocation(MyShader7->ID, "modelMat"), 1, GL_FALSE, glm::value_ptr(modelMat7));//��uniform��������λ�ƾ���
			glUniformMatrix4fv(glGetUniformLocation(MyShader7->ID, "viewMat"), 1, GL_FALSE, glm::value_ptr(viewMat));//��uniform���������ӽǾ���
			glUniformMatrix4fv(glGetUniformLocation(MyShader7->ID, "projMat"), 1, GL_FALSE, glm::value_ptr(projMat));//��uniform��������ͶӰ����
			glUniform3f(glGetUniformLocation(MyShader7->ID, "ObjColor"), 1.0f, 1.0f, 1.0f);//���ϵ���ɫ
			glUniform3f(glGetUniformLocation(MyShader7->ID, "AmbientColor"), 1.0f, 1.0f, 1.0f);//������
			glUniform3f(glGetUniformLocation(MyShader7->ID, "LightPos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);//��Դλ��
			glUniform3f(glGetUniformLocation(MyShader7->ID, "LightColor"), MyLight.color.x, MyLight.color.y, MyLight.color.z);//��Դ��ɫ
			glUniform3f(glGetUniformLocation(MyShader7->ID, "LightDirUniform"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);//��Դ����

			//ƽ�й�
			glUniform3f(glGetUniformLocation(MyShader7->ID, "lightdirectional.Pos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);
			glUniform3f(glGetUniformLocation(MyShader7->ID, "lightdirectional.DirToLight"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);
			glUniform3f(glGetUniformLocation(MyShader7->ID, "lightdirectional.Color"), MyLight.color.x, MyLight.color.y, MyLight.color.z);
			//���Դ0
			glUniform3f(glGetUniformLocation(MyShader7->ID, "lightpoint0.Pos"), MyLight0.position.x, MyLight0.position.y, MyLight0.position.z);
			glUniform3f(glGetUniformLocation(MyShader7->ID, "lightpoint0.DirToLight"), MyLight0.direction.x, MyLight0.direction.y, MyLight0.direction.z);
			glUniform3f(glGetUniformLocation(MyShader7->ID, "lightpoint0.Color"), MyLight0.color.x, MyLight0.color.y, MyLight0.color.z);
			glUniform1f(glGetUniformLocation(MyShader7->ID, "lightpoint0.constant"), MyLight0.constant);
			glUniform1f(glGetUniformLocation(MyShader7->ID, "lightpoint0.linear"), MyLight0.linear);
			glUniform1f(glGetUniformLocation(MyShader7->ID, "lightpoint0.quadratic"), MyLight0.quadratic);

			//�۹��
			glUniform3f(glGetUniformLocation(MyShader7->ID, "lightspot.Pos"), MyLightSpot.position.x, MyLightSpot.position.y, MyLightSpot.position.z);
			glUniform3f(glGetUniformLocation(MyShader7->ID, "lightspot.DirToLight"), MyLightSpot.direction.x, MyLightSpot.direction.y, MyLightSpot.direction.z);
			glUniform3f(glGetUniformLocation(MyShader7->ID, "lightspot.Color"), MyLightSpot.color.x, MyLightSpot.color.y, MyLightSpot.color.z);
			glUniform1f(glGetUniformLocation(MyShader7->ID, "lightspot.constant"), MyLightSpot.constant);
			glUniform1f(glGetUniformLocation(MyShader7->ID, "lightspot.linear"), MyLightSpot.linear);
			glUniform1f(glGetUniformLocation(MyShader7->ID, "lightspot.quadratic"), MyLightSpot.quadratic);
			glUniform1f(glGetUniformLocation(MyShader7->ID, "lightspot.cosInnerPhy"), MyLightSpot.cosInnerPhy);
			glUniform1f(glGetUniformLocation(MyShader7->ID, "lightspot.cosOutterPhy"), MyLightSpot.cosOutterPhy);

			glUniform3f(glGetUniformLocation(MyShader7->ID, "CameraPos"), MyCamera.Position.x, MyCamera.Position.y, MyCamera.Position.z);//�ӽ�λ�ã�Ӱ�쾵�淴�䣩
			MyMaterial7->shader->SetUniform3f("material.ambient", MyMaterial7->ambient);
			MyMaterial7->shader->SetUniform1i("material.diffuse", 4);
			MyMaterial7->shader->SetUniform1i("material.specular", 2);
			MyMaterial7->shader->SetUniform1f("material.shininess", MyMaterial7->shininess);
			model7.Draw(MyMaterial7->shader);
#pragma endregion

			//���ܲ�
#pragma region Shader8 set and use, Draw model8
			MyShader8->use();
			//modelMat4 = glm::translate(glm::mat4(1.0f), glm::vec3(60.0f, 0.0f, 5.0f));

			modelMat8 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -10.0f, 0.0f));
			//modelMat1 = glm::translate(modelMat1, glm::vec3((500 * sin(-0.05f*(float)glfwGetTime())), 0.0f, -50 + 500 * cos(-0.05f*(float)glfwGetTime())));
			modelMat8 = glm::translate(modelMat8, glm::vec3((110 * sin(-0.3f*(float)glfwGetTime())) + (500 * sin(-0.05f*(float)glfwGetTime())), 40.0f, -50 + 110 * cos(-0.3f*(float)glfwGetTime()) + 500 * cos(-0.05f*(float)glfwGetTime())));

			modelMat8 = glm::scale(modelMat8, glm::vec3(8.0f, 8.0f, 8.0f));
			modelMat8 = glm::rotate(modelMat8, -0.8f*(float)glfwGetTime(), glm::vec3(0.0f, 1.0f, 0.0f));
			//modelMat1 = glm::rotate(modelMat1, (float)glfwGetTime(), glm::vec3(1.0f, 1.0f, 1.0f));
			glUniformMatrix4fv(glGetUniformLocation(MyShader8->ID, "modelMat"), 1, GL_FALSE, glm::value_ptr(modelMat8));//��uniform��������λ�ƾ���
			glUniformMatrix4fv(glGetUniformLocation(MyShader8->ID, "viewMat"), 1, GL_FALSE, glm::value_ptr(viewMat));//��uniform���������ӽǾ���
			glUniformMatrix4fv(glGetUniformLocation(MyShader8->ID, "projMat"), 1, GL_FALSE, glm::value_ptr(projMat));//��uniform��������ͶӰ����
			glUniform3f(glGetUniformLocation(MyShader8->ID, "ObjColor"), 1.0f, 1.0f, 1.0f);//���ϵ���ɫ
			glUniform3f(glGetUniformLocation(MyShader8->ID, "AmbientColor"), 1.0f, 1.0f, 1.0f);//������
			glUniform3f(glGetUniformLocation(MyShader8->ID, "LightPos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);//��Դλ��
			glUniform3f(glGetUniformLocation(MyShader8->ID, "LightColor"), MyLight.color.x, MyLight.color.y, MyLight.color.z);//��Դ��ɫ
			glUniform3f(glGetUniformLocation(MyShader8->ID, "LightDirUniform"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);//��Դ����

			//ƽ�й�
			glUniform3f(glGetUniformLocation(MyShader8->ID, "lightdirectional.Pos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);
			glUniform3f(glGetUniformLocation(MyShader8->ID, "lightdirectional.DirToLight"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);
			glUniform3f(glGetUniformLocation(MyShader8->ID, "lightdirectional.Color"), MyLight.color.x, MyLight.color.y, MyLight.color.z);
			//���Դ0
			glUniform3f(glGetUniformLocation(MyShader8->ID, "lightpoint0.Pos"), MyLight0.position.x, MyLight0.position.y, MyLight0.position.z);
			glUniform3f(glGetUniformLocation(MyShader8->ID, "lightpoint0.DirToLight"), MyLight0.direction.x, MyLight0.direction.y, MyLight0.direction.z);
			glUniform3f(glGetUniformLocation(MyShader8->ID, "lightpoint0.Color"), MyLight0.color.x, MyLight0.color.y, MyLight0.color.z);
			glUniform1f(glGetUniformLocation(MyShader8->ID, "lightpoint0.constant"), MyLight0.constant);
			glUniform1f(glGetUniformLocation(MyShader8->ID, "lightpoint0.linear"), MyLight0.linear);
			glUniform1f(glGetUniformLocation(MyShader8->ID, "lightpoint0.quadratic"), MyLight0.quadratic);

			//�۹��
			glUniform3f(glGetUniformLocation(MyShader8->ID, "lightspot.Pos"), MyLightSpot.position.x, MyLightSpot.position.y, MyLightSpot.position.z);
			glUniform3f(glGetUniformLocation(MyShader8->ID, "lightspot.DirToLight"), MyLightSpot.direction.x, MyLightSpot.direction.y, MyLightSpot.direction.z);
			glUniform3f(glGetUniformLocation(MyShader8->ID, "lightspot.Color"), MyLightSpot.color.x, MyLightSpot.color.y, MyLightSpot.color.z);
			glUniform1f(glGetUniformLocation(MyShader8->ID, "lightspot.constant"), MyLightSpot.constant);
			glUniform1f(glGetUniformLocation(MyShader8->ID, "lightspot.linear"), MyLightSpot.linear);
			glUniform1f(glGetUniformLocation(MyShader8->ID, "lightspot.quadratic"), MyLightSpot.quadratic);
			glUniform1f(glGetUniformLocation(MyShader8->ID, "lightspot.cosInnerPhy"), MyLightSpot.cosInnerPhy);
			glUniform1f(glGetUniformLocation(MyShader8->ID, "lightspot.cosOutterPhy"), MyLightSpot.cosOutterPhy);

			glUniform3f(glGetUniformLocation(MyShader8->ID, "CameraPos"), MyCamera.Position.x, MyCamera.Position.y, MyCamera.Position.z);//�ӽ�λ�ã�Ӱ�쾵�淴�䣩
			MyMaterial8->shader->SetUniform3f("material.ambient", MyMaterial8->ambient);
			MyMaterial8->shader->SetUniform1i("material.diffuse", 6);
			MyMaterial8->shader->SetUniform1i("material.specular", 2);
			MyMaterial8->shader->SetUniform1f("material.shininess", MyMaterial8->shininess);
			model8.Draw(MyMaterial8->shader);
#pragma endregion 

			//������
#pragma region Shader9 set and use, Draw model9
			MyShader9->use();
			//modelMat4 = glm::translate(glm::mat4(1.0f), glm::vec3(60.0f, 0.0f, 5.0f));

			modelMat9 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -10.0f, 0.0f));
			//modelMat1 = glm::translate(modelMat1, glm::vec3((500 * sin(-0.05f*(float)glfwGetTime())), 0.0f, -50 + 500 * cos(-0.05f*(float)glfwGetTime())));
			modelMat9 = glm::translate(modelMat9, glm::vec3((110 * sin(-0.8f*(float)glfwGetTime())) + (500 * sin(-0.05f*(float)glfwGetTime())), -40.0f, -50 + 110 * cos(-0.8f*(float)glfwGetTime()) + 500 * cos(-0.05f*(float)glfwGetTime())));

			modelMat9 = glm::scale(modelMat9, glm::vec3(4.0f, 4.0f, 4.0f));
			modelMat9 = glm::rotate(modelMat9, -1.6f*(float)glfwGetTime(), glm::vec3(0.0f, 1.0f, 0.0f));
			//modelMat1 = glm::rotate(modelMat1, (float)glfwGetTime(), glm::vec3(1.0f, 1.0f, 1.0f));
			glUniformMatrix4fv(glGetUniformLocation(MyShader9->ID, "modelMat"), 1, GL_FALSE, glm::value_ptr(modelMat9));//��uniform��������λ�ƾ���
			glUniformMatrix4fv(glGetUniformLocation(MyShader9->ID, "viewMat"), 1, GL_FALSE, glm::value_ptr(viewMat));//��uniform���������ӽǾ���
			glUniformMatrix4fv(glGetUniformLocation(MyShader9->ID, "projMat"), 1, GL_FALSE, glm::value_ptr(projMat));//��uniform��������ͶӰ����
			glUniform3f(glGetUniformLocation(MyShader9->ID, "ObjColor"), 1.0f, 1.0f, 1.0f);//���ϵ���ɫ
			glUniform3f(glGetUniformLocation(MyShader9->ID, "AmbientColor"), 1.0f, 1.0f, 1.0f);//������
			glUniform3f(glGetUniformLocation(MyShader9->ID, "LightPos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);//��Դλ��
			glUniform3f(glGetUniformLocation(MyShader9->ID, "LightColor"), MyLight.color.x, MyLight.color.y, MyLight.color.z);//��Դ��ɫ
			glUniform3f(glGetUniformLocation(MyShader9->ID, "LightDirUniform"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);//��Դ����

			//ƽ�й�
			glUniform3f(glGetUniformLocation(MyShader9->ID, "lightdirectional.Pos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);
			glUniform3f(glGetUniformLocation(MyShader9->ID, "lightdirectional.DirToLight"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);
			glUniform3f(glGetUniformLocation(MyShader9->ID, "lightdirectional.Color"), MyLight.color.x, MyLight.color.y, MyLight.color.z);
			//���Դ0
			glUniform3f(glGetUniformLocation(MyShader9->ID, "lightpoint0.Pos"), MyLight0.position.x, MyLight0.position.y, MyLight0.position.z);
			glUniform3f(glGetUniformLocation(MyShader9->ID, "lightpoint0.DirToLight"), MyLight0.direction.x, MyLight0.direction.y, MyLight0.direction.z);
			glUniform3f(glGetUniformLocation(MyShader9->ID, "lightpoint0.Color"), MyLight0.color.x, MyLight0.color.y, MyLight0.color.z);
			glUniform1f(glGetUniformLocation(MyShader9->ID, "lightpoint0.constant"), MyLight0.constant);
			glUniform1f(glGetUniformLocation(MyShader9->ID, "lightpoint0.linear"), MyLight0.linear);
			glUniform1f(glGetUniformLocation(MyShader9->ID, "lightpoint0.quadratic"), MyLight0.quadratic);

			//�۹��
			glUniform3f(glGetUniformLocation(MyShader9->ID, "lightspot.Pos"), MyLightSpot.position.x, MyLightSpot.position.y, MyLightSpot.position.z);
			glUniform3f(glGetUniformLocation(MyShader9->ID, "lightspot.DirToLight"), MyLightSpot.direction.x, MyLightSpot.direction.y, MyLightSpot.direction.z);
			glUniform3f(glGetUniformLocation(MyShader9->ID, "lightspot.Color"), MyLightSpot.color.x, MyLightSpot.color.y, MyLightSpot.color.z);
			glUniform1f(glGetUniformLocation(MyShader9->ID, "lightspot.constant"), MyLightSpot.constant);
			glUniform1f(glGetUniformLocation(MyShader9->ID, "lightspot.linear"), MyLightSpot.linear);
			glUniform1f(glGetUniformLocation(MyShader9->ID, "lightspot.quadratic"), MyLightSpot.quadratic);
			glUniform1f(glGetUniformLocation(MyShader9->ID, "lightspot.cosInnerPhy"), MyLightSpot.cosInnerPhy);
			glUniform1f(glGetUniformLocation(MyShader9->ID, "lightspot.cosOutterPhy"), MyLightSpot.cosOutterPhy);

			glUniform3f(glGetUniformLocation(MyShader9->ID, "CameraPos"), MyCamera.Position.x, MyCamera.Position.y, MyCamera.Position.z);//�ӽ�λ�ã�Ӱ�쾵�淴�䣩
			MyMaterial9->shader->SetUniform3f("material.ambient", MyMaterial9->ambient);
			MyMaterial9->shader->SetUniform1i("material.diffuse", 8);
			MyMaterial9->shader->SetUniform1i("material.specular", 2);
			MyMaterial9->shader->SetUniform1f("material.shininess", MyMaterial9->shininess);
			model9.Draw(MyMaterial9->shader);
#pragma endregion 

			//��֭
#pragma region Shader10 set and use, Draw model10
			MyShader10->use();
			//modelMat4 = glm::translate(glm::mat4(1.0f), glm::vec3(60.0f, 0.0f, 5.0f));

			modelMat10 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -10.0f, 0.0f));
			//modelMat1 = glm::translate(modelMat1, glm::vec3((500 * sin(-0.05f*(float)glfwGetTime())), 0.0f, -50 + 500 * cos(-0.05f*(float)glfwGetTime())));
			modelMat10 = glm::translate(modelMat10, glm::vec3((110 * sin(-0.2f*(float)glfwGetTime())) + (760 * sin(0.25f*(float)glfwGetTime())), 0.0f, -50 + 110 * cos(-0.2f*(float)glfwGetTime()) + 760 * cos(0.25f*(float)glfwGetTime())));

			modelMat10 = glm::scale(modelMat10, glm::vec3(4.0f, 4.0f, 4.0f));
			modelMat10 = glm::rotate(modelMat10, -1.6f*(float)glfwGetTime(), glm::vec3(0.0f, 1.0f, 0.0f));
			//modelMat1 = glm::rotate(modelMat1, (float)glfwGetTime(), glm::vec3(1.0f, 1.0f, 1.0f));
			glUniformMatrix4fv(glGetUniformLocation(MyShader10->ID, "modelMat"), 1, GL_FALSE, glm::value_ptr(modelMat10));//��uniform��������λ�ƾ���
			glUniformMatrix4fv(glGetUniformLocation(MyShader10->ID, "viewMat"), 1, GL_FALSE, glm::value_ptr(viewMat));//��uniform���������ӽǾ���
			glUniformMatrix4fv(glGetUniformLocation(MyShader10->ID, "projMat"), 1, GL_FALSE, glm::value_ptr(projMat));//��uniform��������ͶӰ����
			glUniform3f(glGetUniformLocation(MyShader10->ID, "ObjColor"), 1.0f, 1.0f, 1.0f);//���ϵ���ɫ
			glUniform3f(glGetUniformLocation(MyShader10->ID, "AmbientColor"), 1.0f, 1.0f, 1.0f);//������
			glUniform3f(glGetUniformLocation(MyShader10->ID, "LightPos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);//��Դλ��
			glUniform3f(glGetUniformLocation(MyShader10->ID, "LightColor"), MyLight.color.x, MyLight.color.y, MyLight.color.z);//��Դ��ɫ
			glUniform3f(glGetUniformLocation(MyShader10->ID, "LightDirUniform"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);//��Դ����

			//ƽ�й�
			glUniform3f(glGetUniformLocation(MyShader10->ID, "lightdirectional.Pos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);
			glUniform3f(glGetUniformLocation(MyShader10->ID, "lightdirectional.DirToLight"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);
			glUniform3f(glGetUniformLocation(MyShader10->ID, "lightdirectional.Color"), MyLight.color.x, MyLight.color.y, MyLight.color.z);
			//���Դ0
			glUniform3f(glGetUniformLocation(MyShader10->ID, "lightpoint0.Pos"), MyLight0.position.x, MyLight0.position.y, MyLight0.position.z);
			glUniform3f(glGetUniformLocation(MyShader10->ID, "lightpoint0.DirToLight"), MyLight0.direction.x, MyLight0.direction.y, MyLight0.direction.z);
			glUniform3f(glGetUniformLocation(MyShader10->ID, "lightpoint0.Color"), MyLight0.color.x, MyLight0.color.y, MyLight0.color.z);
			glUniform1f(glGetUniformLocation(MyShader10->ID, "lightpoint0.constant"), MyLight0.constant);
			glUniform1f(glGetUniformLocation(MyShader10->ID, "lightpoint0.linear"), MyLight0.linear);
			glUniform1f(glGetUniformLocation(MyShader10->ID, "lightpoint0.quadratic"), MyLight0.quadratic);

			//�۹��
			glUniform3f(glGetUniformLocation(MyShader10->ID, "lightspot.Pos"), MyLightSpot.position.x, MyLightSpot.position.y, MyLightSpot.position.z);
			glUniform3f(glGetUniformLocation(MyShader10->ID, "lightspot.DirToLight"), MyLightSpot.direction.x, MyLightSpot.direction.y, MyLightSpot.direction.z);
			glUniform3f(glGetUniformLocation(MyShader10->ID, "lightspot.Color"), MyLightSpot.color.x, MyLightSpot.color.y, MyLightSpot.color.z);
			glUniform1f(glGetUniformLocation(MyShader10->ID, "lightspot.constant"), MyLightSpot.constant);
			glUniform1f(glGetUniformLocation(MyShader10->ID, "lightspot.linear"), MyLightSpot.linear);
			glUniform1f(glGetUniformLocation(MyShader10->ID, "lightspot.quadratic"), MyLightSpot.quadratic);
			glUniform1f(glGetUniformLocation(MyShader10->ID, "lightspot.cosInnerPhy"), MyLightSpot.cosInnerPhy);
			glUniform1f(glGetUniformLocation(MyShader10->ID, "lightspot.cosOutterPhy"), MyLightSpot.cosOutterPhy);

			glUniform3f(glGetUniformLocation(MyShader10->ID, "CameraPos"), MyCamera.Position.x, MyCamera.Position.y, MyCamera.Position.z);//�ӽ�λ�ã�Ӱ�쾵�淴�䣩
			MyMaterial10->shader->SetUniform3f("material.ambient", MyMaterial10->ambient);
			MyMaterial10->shader->SetUniform1i("material.diffuse", 10);
			MyMaterial10->shader->SetUniform1i("material.specular", 2);
			MyMaterial10->shader->SetUniform1f("material.shininess", MyMaterial10->shininess);
			model10.Draw(MyMaterial10->shader);
#pragma endregion 


//Clean up, prepare for next render loop
			glfwSwapBuffers(MyWindow);//ˢ��
			glfwPollEvents();//��ȡ����
			MyCamera.UpdateCameraPosition();
		}
		//Exit program
		glfwTerminate();
		return 0;
	}

	else if (UpperMode) {
	//MyCamera.Pitch = glm::radians(-90.0f);
	while (!glfwWindowShouldClose(MyWindow)) {//��Ⱦѭ��
		//MyCamera.Pitch = glm::radians(-90.0f);
		MyCamera.Position = glm::vec3(0,800.0f, 0.0f);
		
		viewMat = MyCamera.GetViewMatrix(MyCamera.Position);//�ӽǱ任


		//����ǰ��������ƺ���
		processInput1(MyWindow);

		//���&���ñ�����ɫ
		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);//RGB��ֵ����͸����1.0
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);//�����ɫ�����

			//������
#pragma region Shader3 set and use, Draw model3
		MyShader3->use();
		modelMat3 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -0.0f, -50.0f));
		modelMat3 = glm::rotate(modelMat3, 0.07f*(float)glfwGetTime(), glm::vec3(0.0f, 1.0f, 0.0f));
		modelMat3 = glm::scale(modelMat3, glm::vec3(1200.0f, 1200.0f, 1200.0f));
		//modelMat1 = glm::rotate(modelMat1, (float)glfwGetTime(), glm::vec3(1.0f, 1.0f, 1.0f));
		glUniformMatrix4fv(glGetUniformLocation(MyShader3->ID, "modelMat"), 1, GL_FALSE, glm::value_ptr(modelMat3));//��uniform��������λ�ƾ���
		glUniformMatrix4fv(glGetUniformLocation(MyShader3->ID, "viewMat"), 1, GL_FALSE, glm::value_ptr(viewMat));//��uniform���������ӽǾ���
		glUniformMatrix4fv(glGetUniformLocation(MyShader3->ID, "projMat"), 1, GL_FALSE, glm::value_ptr(projMat));//��uniform��������ͶӰ����
		glUniform3f(glGetUniformLocation(MyShader3->ID, "ObjColor"), 10.0f, 10.0f, 10.0f);//���ϵ���ɫ
		glUniform3f(glGetUniformLocation(MyShader3->ID, "AmbientColor"), 2.5f, 2.5f, 2.5f);//������
		glUniform3f(glGetUniformLocation(MyShader3->ID, "LightPos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);//��Դλ��
		glUniform3f(glGetUniformLocation(MyShader3->ID, "LightColor"), MyLight.color.x, MyLight.color.y, MyLight.color.z);//��Դ��ɫ
		glUniform3f(glGetUniformLocation(MyShader3->ID, "LightDirUniform"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);//��Դ����

		//ƽ�й�
		glUniform3f(glGetUniformLocation(MyShader3->ID, "lightdirectional.Pos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);
		glUniform3f(glGetUniformLocation(MyShader3->ID, "lightdirectional.DirToLight"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);
		glUniform3f(glGetUniformLocation(MyShader3->ID, "lightdirectional.Color"), MyLight.color.x, MyLight.color.y, MyLight.color.z);
		//���Դ0
		glUniform3f(glGetUniformLocation(MyShader3->ID, "lightpoint0.Pos"), MyLight0.position.x, MyLight0.position.y, MyLight0.position.z);
		glUniform3f(glGetUniformLocation(MyShader3->ID, "lightpoint0.DirToLight"), MyLight0.direction.x, MyLight0.direction.y, MyLight0.direction.z);
		glUniform3f(glGetUniformLocation(MyShader3->ID, "lightpoint0.Color"), MyLight0.color.x, MyLight0.color.y, MyLight0.color.z);
		glUniform1f(glGetUniformLocation(MyShader3->ID, "lightpoint0.constant"), MyLight0.constant);
		glUniform1f(glGetUniformLocation(MyShader3->ID, "lightpoint0.linear"), MyLight0.linear);
		glUniform1f(glGetUniformLocation(MyShader3->ID, "lightpoint0.quadratic"), MyLight0.quadratic);

		//�۹��
		glUniform3f(glGetUniformLocation(MyShader3->ID, "lightspot.Pos"), MyLightSpot.position.x, MyLightSpot.position.y, MyLightSpot.position.z);
		glUniform3f(glGetUniformLocation(MyShader3->ID, "lightspot.DirToLight"), MyLightSpot.direction.x, MyLightSpot.direction.y, MyLightSpot.direction.z);
		glUniform3f(glGetUniformLocation(MyShader3->ID, "lightspot.Color"), MyLightSpot.color.x, MyLightSpot.color.y, MyLightSpot.color.z);
		glUniform1f(glGetUniformLocation(MyShader3->ID, "lightspot.constant"), MyLightSpot.constant);
		glUniform1f(glGetUniformLocation(MyShader3->ID, "lightspot.linear"), MyLightSpot.linear);
		glUniform1f(glGetUniformLocation(MyShader3->ID, "lightspot.quadratic"), MyLightSpot.quadratic);
		glUniform1f(glGetUniformLocation(MyShader3->ID, "lightspot.cosInnerPhy"), MyLightSpot.cosInnerPhy);
		glUniform1f(glGetUniformLocation(MyShader3->ID, "lightspot.cosOutterPhy"), MyLightSpot.cosOutterPhy);

		glUniform3f(glGetUniformLocation(MyShader3->ID, "CameraPos"), MyCamera.Position.x, MyCamera.Position.y, MyCamera.Position.z);//�ӽ�λ�ã�Ӱ�쾵�淴�䣩
		MyMaterial3->shader->SetUniform3f("material.ambient", MyMaterial3->ambient);
		MyMaterial3->shader->SetUniform1i("material.diffuse", 7);
		MyMaterial3->shader->SetUniform1i("material.specular", 8);
		MyMaterial3->shader->SetUniform1f("material.shininess", MyMaterial3->shininess);
		model3.Draw(MyMaterial3->shader);
#pragma endregion

		//�ɴ�
#pragma region Shader0 set and use, Draw model0
		MyShader->use();
		//modelMat = viewMat;					
		//modelMat = glm::translate(glm::mat4(1.0f), glm::vec3(0, 450.0f, 1000.0f));
		//modelMat = glm::translate(glm::mat4(1.0f), glm::vec3((modelposition.x *(-MyCamera.Forward.z)+ modelposition.z*(MyCamera.Forward.x)), 
		//													modelposition.y, 
		//													(modelposition.x*(1+MyCamera.Forward.z)- modelposition.z*(1-MyCamera.Forward.x))));
		modelMat = glm::translate(glm::mat4(1.0f), glm::vec3(modelposition.x,modelposition.y,modelposition.z));
		//modelMat = glm::rotate(modelMat, glm::radians(180.0f), glm::vec3(0.0f, 1.0f, 0.0f));
		if (MyCamera.Forward.z <= 0) { modelMat = glm::rotate(modelMat, -1.0f*MyCamera.Forward.x, glm::vec3(0.0f, 1.0f, 0.0f)); }
		else if (MyCamera.Forward.z > 0) { modelMat = glm::rotate(modelMat, 1.0f*MyCamera.Forward.x + glm::radians(180.0f), glm::vec3(0.0f, 1.0f, 0.0f)); }
		//modelMat = glm::rotate(modelMat, 1.4f*MyCamera.Forward.y, glm::vec3(1.0f, 0.0f, 0.0f));
		modelMat = glm::rotate(modelMat, glm::radians(270.0f), glm::vec3(0.0f, 1.0f, 0.0f));
		//modelMat = glm::rotate(modelMat, glm::radians(45.0f), glm::vec3(1.0f, 0.0f, 0.0f));
		modelMat = glm::scale(modelMat, glm::vec3(0.01f, 0.01f, 0.01f));
		MyLightSpot.position = glm::vec3(MyCamera.Position.x + (5 * MyCamera.Forward.x), MyCamera.Position.y - 2 + (5 * MyCamera.Forward.y), MyCamera.Position.z + (5 * MyCamera.Forward.z));
		//MyLightSpot.position = MyCamera.Position;
		MyLightSpot.direction = -MyCamera.Forward;
		glUniformMatrix4fv(glGetUniformLocation(MyShader->ID, "modelMat"), 1, GL_FALSE, glm::value_ptr(modelMat));//��uniform��������λ�ƾ���
		glUniformMatrix4fv(glGetUniformLocation(MyShader->ID, "viewMat"), 1, GL_FALSE, glm::value_ptr(viewMat));//��uniform���������ӽǾ���
		glUniformMatrix4fv(glGetUniformLocation(MyShader->ID, "projMat"), 1, GL_FALSE, glm::value_ptr(projMat));//��uniform��������ͶӰ����
		glUniform3f(glGetUniformLocation(MyShader->ID, "ObjColor"), 1.0f, 1.0f, 1.0f);//���ϵ���ɫ
		glUniform3f(glGetUniformLocation(MyShader->ID, "AmbientColor"), 2.0f, 2.0f, 2.0f);//������
		glUniform3f(glGetUniformLocation(MyShader->ID, "LightPos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);//��Դλ��
		glUniform3f(glGetUniformLocation(MyShader->ID, "LightColor"), MyLight.color.x, MyLight.color.y, MyLight.color.z);//��Դ��ɫ
		glUniform3f(glGetUniformLocation(MyShader->ID, "LightDirUniform"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);//��Դ����

		//ƽ�й�
		glUniform3f(glGetUniformLocation(MyShader->ID, "lightdirectional.Pos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);
		glUniform3f(glGetUniformLocation(MyShader->ID, "lightdirectional.DirToLight"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);
		glUniform3f(glGetUniformLocation(MyShader->ID, "lightdirectional.Color"), MyLight.color.x, MyLight.color.y, MyLight.color.z);
		//���Դ0
		glUniform3f(glGetUniformLocation(MyShader->ID, "lightpoint0.Pos"), MyLight0.position.x, MyLight0.position.y, MyLight0.position.z);
		glUniform3f(glGetUniformLocation(MyShader->ID, "lightpoint0.DirToLight"), MyLight0.direction.x, MyLight0.direction.y, MyLight0.direction.z);
		glUniform3f(glGetUniformLocation(MyShader->ID, "lightpoint0.Color"), MyLight0.color.x, MyLight0.color.y, MyLight0.color.z);
		glUniform1f(glGetUniformLocation(MyShader->ID, "lightpoint0.constant"), MyLight0.constant);
		glUniform1f(glGetUniformLocation(MyShader->ID, "lightpoint0.linear"), MyLight0.linear);
		glUniform1f(glGetUniformLocation(MyShader->ID, "lightpoint0.quadratic"), MyLight0.quadratic);

		//�۹��
		glUniform3f(glGetUniformLocation(MyShader->ID, "lightspot.Pos"), MyLightSpot.position.x, MyLightSpot.position.y, MyLightSpot.position.z);
		glUniform3f(glGetUniformLocation(MyShader->ID, "lightspot.DirToLight"), MyLightSpot.direction.x, MyLightSpot.direction.y, MyLightSpot.direction.z);
		glUniform3f(glGetUniformLocation(MyShader->ID, "lightspot.Color"), 0.1f*MyLightSpot.color.x, 0.1f*MyLightSpot.color.y, 0.1f*MyLightSpot.color.z);
		glUniform1f(glGetUniformLocation(MyShader->ID, "lightspot.constant"), MyLightSpot.constant);
		glUniform1f(glGetUniformLocation(MyShader->ID, "lightspot.linear"), MyLightSpot.linear);
		glUniform1f(glGetUniformLocation(MyShader->ID, "lightspot.quadratic"), MyLightSpot.quadratic);
		glUniform1f(glGetUniformLocation(MyShader->ID, "lightspot.cosInnerPhy"), MyLightSpot.cosInnerPhy);
		glUniform1f(glGetUniformLocation(MyShader->ID, "lightspot.cosOutterPhy"), MyLightSpot.cosOutterPhy);

		glUniform3f(glGetUniformLocation(MyShader->ID, "CameraPos"), MyCamera.Position.x, MyCamera.Position.y, MyCamera.Position.z);//�ӽ�λ�ã�Ӱ�쾵�淴�䣩
		MyMaterial->shader->SetUniform3f("material.ambient", MyMaterial->ambient);
		MyMaterial->shader->SetUniform1i("material.diffuse", 1);
		MyMaterial->shader->SetUniform1i("material.specular", 2);
		MyMaterial->shader->SetUniform1f("material.shininess", MyMaterial->shininess);
		model0.Draw(MyMaterial->shader);
#pragma endregion		

		//ԭ������
#pragma region Shader1 set and use, Draw model1
		MyShader1->use();
		modelMat1 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -10.0f, 0.0f));
		//modelMat3 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -10.0f, -50.0f));
		modelMat1 = glm::translate(modelMat1, glm::vec3((500 * sin(-0.05f*(float)glfwGetTime())), 0.0f, -50 + 500 * cos(-0.05f*(float)glfwGetTime())));
		modelMat1 = glm::rotate(modelMat1, -0.6f*(float)glfwGetTime(), glm::vec3(0.0f, 1.0f, 0.0f));
		modelMat1 = glm::scale(modelMat1, glm::vec3(400.0f, 400.0f, 400.0f));
		glUniformMatrix4fv(glGetUniformLocation(MyShader1->ID, "modelMat"), 1, GL_FALSE, glm::value_ptr(modelMat1));//��uniform��������λ�ƾ���
		glUniformMatrix4fv(glGetUniformLocation(MyShader1->ID, "viewMat"), 1, GL_FALSE, glm::value_ptr(viewMat));//��uniform���������ӽǾ���
		glUniformMatrix4fv(glGetUniformLocation(MyShader1->ID, "projMat"), 1, GL_FALSE, glm::value_ptr(projMat));//��uniform��������ͶӰ����
		glUniform3f(glGetUniformLocation(MyShader1->ID, "ObjColor"), 1.0f, 1.0f, 1.0f);//���ϵ���ɫ
		glUniform3f(glGetUniformLocation(MyShader1->ID, "AmbientColor"), 1.0f, 1.0f, 1.0f);//������
		glUniform3f(glGetUniformLocation(MyShader1->ID, "LightPos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);//��Դλ��
		glUniform3f(glGetUniformLocation(MyShader1->ID, "LightColor"), MyLight.color.x, MyLight.color.y, MyLight.color.z);//��Դ��ɫ
		glUniform3f(glGetUniformLocation(MyShader1->ID, "LightDirUniform"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);//��Դ����

		//ƽ�й�
		glUniform3f(glGetUniformLocation(MyShader1->ID, "lightdirectional.Pos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);
		glUniform3f(glGetUniformLocation(MyShader1->ID, "lightdirectional.DirToLight"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);
		glUniform3f(glGetUniformLocation(MyShader1->ID, "lightdirectional.Color"), MyLight.color.x, MyLight.color.y, MyLight.color.z);
		//���Դ0
		glUniform3f(glGetUniformLocation(MyShader1->ID, "lightpoint0.Pos"), MyLight0.position.x, MyLight0.position.y, MyLight0.position.z);
		glUniform3f(glGetUniformLocation(MyShader1->ID, "lightpoint0.DirToLight"), MyLight0.direction.x, MyLight0.direction.y, MyLight0.direction.z);
		glUniform3f(glGetUniformLocation(MyShader1->ID, "lightpoint0.Color"), MyLight0.color.x, MyLight0.color.y, MyLight0.color.z);
		glUniform1f(glGetUniformLocation(MyShader1->ID, "lightpoint0.constant"), MyLight0.constant);
		glUniform1f(glGetUniformLocation(MyShader1->ID, "lightpoint0.linear"), MyLight0.linear);
		glUniform1f(glGetUniformLocation(MyShader1->ID, "lightpoint0.quadratic"), MyLight0.quadratic);

		//�۹��
		glUniform3f(glGetUniformLocation(MyShader1->ID, "lightspot.Pos"), MyLightSpot.position.x, MyLightSpot.position.y, MyLightSpot.position.z);
		glUniform3f(glGetUniformLocation(MyShader1->ID, "lightspot.DirToLight"), MyLightSpot.direction.x, MyLightSpot.direction.y, MyLightSpot.direction.z);
		glUniform3f(glGetUniformLocation(MyShader1->ID, "lightspot.Color"), MyLightSpot.color.x, MyLightSpot.color.y, MyLightSpot.color.z);
		glUniform1f(glGetUniformLocation(MyShader1->ID, "lightspot.constant"), MyLightSpot.constant);
		glUniform1f(glGetUniformLocation(MyShader1->ID, "lightspot.linear"), MyLightSpot.linear);
		glUniform1f(glGetUniformLocation(MyShader1->ID, "lightspot.quadratic"), MyLightSpot.quadratic);
		glUniform1f(glGetUniformLocation(MyShader1->ID, "lightspot.cosInnerPhy"), MyLightSpot.cosInnerPhy);
		glUniform1f(glGetUniformLocation(MyShader1->ID, "lightspot.cosOutterPhy"), MyLightSpot.cosOutterPhy);

		glUniform3f(glGetUniformLocation(MyShader1->ID, "CameraPos"), MyCamera.Position.x, MyCamera.Position.y, MyCamera.Position.z);//�ӽ�λ�ã�Ӱ�쾵�淴�䣩
		MyMaterial1->shader->SetUniform3f("material.ambient", MyMaterial1->ambient);
		MyMaterial1->shader->SetUniform1i("material.diffuse", 3);
		MyMaterial1->shader->SetUniform1i("material.specular", 4);
		MyMaterial1->shader->SetUniform1f("material.shininess", MyMaterial1->shininess);
		model1.Draw(MyMaterial1->shader);
#pragma endregion

		//������
#pragma region Shader2 set and use, Draw model2
		MyShader2->use();
		modelMat2 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -10.0f, 0.0f));
		modelMat2 = glm::translate(modelMat2, glm::vec3((1200 * sin(0.05f*(float)glfwGetTime())), 0.0f, -50 + 1200 * cos(0.05f*(float)glfwGetTime())));
		modelMat2 = glm::scale(modelMat2, glm::vec3(360.0f, 360.0f, 360.0f));
		modelMat2 = glm::rotate(modelMat2, 0.6f*(float)glfwGetTime(), glm::vec3(0.0f, 1.0f, 0.0f));
		//modelMat1 = glm::rotate(modelMat1, (float)glfwGetTime(), glm::vec3(1.0f, 1.0f, 1.0f));
		glUniformMatrix4fv(glGetUniformLocation(MyShader2->ID, "modelMat"), 1, GL_FALSE, glm::value_ptr(modelMat2));//��uniform��������λ�ƾ���
		glUniformMatrix4fv(glGetUniformLocation(MyShader2->ID, "viewMat"), 1, GL_FALSE, glm::value_ptr(viewMat));//��uniform���������ӽǾ���
		glUniformMatrix4fv(glGetUniformLocation(MyShader2->ID, "projMat"), 1, GL_FALSE, glm::value_ptr(projMat));//��uniform��������ͶӰ����
		glUniform3f(glGetUniformLocation(MyShader2->ID, "ObjColor"), 1.0f, 1.0f, 1.0f);//���ϵ���ɫ
		glUniform3f(glGetUniformLocation(MyShader2->ID, "AmbientColor"), 1.0f, 1.0f, 1.0f);//������
		glUniform3f(glGetUniformLocation(MyShader2->ID, "LightPos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);//��Դλ��
		glUniform3f(glGetUniformLocation(MyShader2->ID, "LightColor"), MyLight.color.x, MyLight.color.y, MyLight.color.z);//��Դ��ɫ
		glUniform3f(glGetUniformLocation(MyShader2->ID, "LightDirUniform"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);//��Դ����

		//ƽ�й�
		glUniform3f(glGetUniformLocation(MyShader2->ID, "lightdirectional.Pos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);
		glUniform3f(glGetUniformLocation(MyShader2->ID, "lightdirectional.DirToLight"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);
		glUniform3f(glGetUniformLocation(MyShader2->ID, "lightdirectional.Color"), MyLight.color.x, MyLight.color.y, MyLight.color.z);
		//���Դ0
		glUniform3f(glGetUniformLocation(MyShader2->ID, "lightpoint0.Pos"), MyLight0.position.x, MyLight0.position.y, MyLight0.position.z);
		glUniform3f(glGetUniformLocation(MyShader2->ID, "lightpoint0.DirToLight"), MyLight0.direction.x, MyLight0.direction.y, MyLight0.direction.z);
		glUniform3f(glGetUniformLocation(MyShader2->ID, "lightpoint0.Color"), MyLight0.color.x, MyLight0.color.y, MyLight0.color.z);
		glUniform1f(glGetUniformLocation(MyShader2->ID, "lightpoint0.constant"), MyLight0.constant);
		glUniform1f(glGetUniformLocation(MyShader2->ID, "lightpoint0.linear"), MyLight0.linear);
		glUniform1f(glGetUniformLocation(MyShader2->ID, "lightpoint0.quadratic"), MyLight0.quadratic);

		//�۹��
		glUniform3f(glGetUniformLocation(MyShader2->ID, "lightspot.Pos"), MyLightSpot.position.x, MyLightSpot.position.y, MyLightSpot.position.z);
		glUniform3f(glGetUniformLocation(MyShader2->ID, "lightspot.DirToLight"), MyLightSpot.direction.x, MyLightSpot.direction.y, MyLightSpot.direction.z);
		glUniform3f(glGetUniformLocation(MyShader2->ID, "lightspot.Color"), MyLightSpot.color.x, MyLightSpot.color.y, MyLightSpot.color.z);
		glUniform1f(glGetUniformLocation(MyShader2->ID, "lightspot.constant"), MyLightSpot.constant);
		glUniform1f(glGetUniformLocation(MyShader2->ID, "lightspot.linear"), MyLightSpot.linear);
		glUniform1f(glGetUniformLocation(MyShader2->ID, "lightspot.quadratic"), MyLightSpot.quadratic);
		glUniform1f(glGetUniformLocation(MyShader2->ID, "lightspot.cosInnerPhy"), MyLightSpot.cosInnerPhy);
		glUniform1f(glGetUniformLocation(MyShader2->ID, "lightspot.cosOutterPhy"), MyLightSpot.cosOutterPhy);

		glUniform3f(glGetUniformLocation(MyShader2->ID, "CameraPos"), MyCamera.Position.x, MyCamera.Position.y, MyCamera.Position.z);//�ӽ�λ�ã�Ӱ�쾵�淴�䣩
		MyMaterial2->shader->SetUniform3f("material.ambient", MyMaterial2->ambient);
		MyMaterial2->shader->SetUniform1i("material.diffuse", 5);
		MyMaterial2->shader->SetUniform1i("material.specular", 6);
		MyMaterial2->shader->SetUniform1f("material.shininess", MyMaterial2->shininess);
		model2.Draw(MyMaterial2->shader);
#pragma endregion


		//����
#pragma region Shader4 set and use, Draw model4
		MyShader4->use();
		//modelMat4 = glm::translate(glm::mat4(1.0f), glm::vec3(60.0f, 0.0f, 5.0f));

		modelMat4 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -10.0f, 0.0f));
		//modelMat2 = glm::translate(modelMat2, glm::vec3((30 * sin(0.3f*(float)glfwGetTime())), 0.0f, -50 + 30 * cos(0.3f*(float)glfwGetTime())));
		modelMat4 = glm::translate(modelMat4, glm::vec3((120 * sin(1.5f*(float)glfwGetTime())) + (1200 * sin(0.05f*(float)glfwGetTime())), 0.0f, -50 + 120 * cos(1.5f*(float)glfwGetTime()) + 1200 * cos(0.05f*(float)glfwGetTime())));

		modelMat4 = glm::scale(modelMat4, glm::vec3(12.0f, 12.0f, 12.0f));
		modelMat4 = glm::rotate(modelMat4, -0.8f*(float)glfwGetTime(), glm::vec3(0.0f, 1.0f, 0.0f));
		//modelMat1 = glm::rotate(modelMat1, (float)glfwGetTime(), glm::vec3(1.0f, 1.0f, 1.0f));
		glUniformMatrix4fv(glGetUniformLocation(MyShader4->ID, "modelMat"), 1, GL_FALSE, glm::value_ptr(modelMat4));//��uniform��������λ�ƾ���
		glUniformMatrix4fv(glGetUniformLocation(MyShader4->ID, "viewMat"), 1, GL_FALSE, glm::value_ptr(viewMat));//��uniform���������ӽǾ���
		glUniformMatrix4fv(glGetUniformLocation(MyShader4->ID, "projMat"), 1, GL_FALSE, glm::value_ptr(projMat));//��uniform��������ͶӰ����
		glUniform3f(glGetUniformLocation(MyShader4->ID, "ObjColor"), 1.0f, 1.0f, 1.0f);//���ϵ���ɫ
		glUniform3f(glGetUniformLocation(MyShader4->ID, "AmbientColor"), 1.0f, 1.0f, 1.0f);//������
		glUniform3f(glGetUniformLocation(MyShader4->ID, "LightPos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);//��Դλ��
		glUniform3f(glGetUniformLocation(MyShader4->ID, "LightColor"), MyLight.color.x, MyLight.color.y, MyLight.color.z);//��Դ��ɫ
		glUniform3f(glGetUniformLocation(MyShader4->ID, "LightDirUniform"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);//��Դ����

		//ƽ�й�
		glUniform3f(glGetUniformLocation(MyShader4->ID, "lightdirectional.Pos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);
		glUniform3f(glGetUniformLocation(MyShader4->ID, "lightdirectional.DirToLight"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);
		glUniform3f(glGetUniformLocation(MyShader4->ID, "lightdirectional.Color"), MyLight.color.x, MyLight.color.y, MyLight.color.z);
		//���Դ0
		glUniform3f(glGetUniformLocation(MyShader4->ID, "lightpoint0.Pos"), MyLight0.position.x, MyLight0.position.y, MyLight0.position.z);
		glUniform3f(glGetUniformLocation(MyShader4->ID, "lightpoint0.DirToLight"), MyLight0.direction.x, MyLight0.direction.y, MyLight0.direction.z);
		glUniform3f(glGetUniformLocation(MyShader4->ID, "lightpoint0.Color"), MyLight0.color.x, MyLight0.color.y, MyLight0.color.z);
		glUniform1f(glGetUniformLocation(MyShader4->ID, "lightpoint0.constant"), MyLight0.constant);
		glUniform1f(glGetUniformLocation(MyShader4->ID, "lightpoint0.linear"), MyLight0.linear);
		glUniform1f(glGetUniformLocation(MyShader4->ID, "lightpoint0.quadratic"), MyLight0.quadratic);

		//�۹��
		glUniform3f(glGetUniformLocation(MyShader4->ID, "lightspot.Pos"), MyLightSpot.position.x, MyLightSpot.position.y, MyLightSpot.position.z);
		glUniform3f(glGetUniformLocation(MyShader4->ID, "lightspot.DirToLight"), MyLightSpot.direction.x, MyLightSpot.direction.y, MyLightSpot.direction.z);
		glUniform3f(glGetUniformLocation(MyShader4->ID, "lightspot.Color"), MyLightSpot.color.x, MyLightSpot.color.y, MyLightSpot.color.z);
		glUniform1f(glGetUniformLocation(MyShader4->ID, "lightspot.constant"), MyLightSpot.constant);
		glUniform1f(glGetUniformLocation(MyShader4->ID, "lightspot.linear"), MyLightSpot.linear);
		glUniform1f(glGetUniformLocation(MyShader4->ID, "lightspot.quadratic"), MyLightSpot.quadratic);
		glUniform1f(glGetUniformLocation(MyShader4->ID, "lightspot.cosInnerPhy"), MyLightSpot.cosInnerPhy);
		glUniform1f(glGetUniformLocation(MyShader4->ID, "lightspot.cosOutterPhy"), MyLightSpot.cosOutterPhy);

		glUniform3f(glGetUniformLocation(MyShader4->ID, "CameraPos"), MyCamera.Position.x, MyCamera.Position.y, MyCamera.Position.z);//�ӽ�λ�ã�Ӱ�쾵�淴�䣩
		MyMaterial4->shader->SetUniform3f("material.ambient", MyMaterial3->ambient);
		MyMaterial4->shader->SetUniform1i("material.diffuse", 9);
		MyMaterial4->shader->SetUniform1i("material.specular", 10);
		MyMaterial4->shader->SetUniform1f("material.shininess", MyMaterial3->shininess);
		model4.Draw(MyMaterial4->shader);
#pragma endregion

		//������
#pragma region Shader5 set and use, Draw model5
		MyShader5->use();
		modelMat5 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -10.0f, -50.0f));
		modelMat5 = glm::rotate(modelMat5, 0.01f*(float)glfwGetTime(), glm::vec3(0.0f, 1.0f, 0.0f));
		modelMat5 = glm::scale(modelMat5, glm::vec3(10000.0f, 10000.0f, 10000.0f));
		//modelMat1 = glm::rotate(modelMat1, (float)glfwGetTime(), glm::vec3(1.0f, 1.0f, 1.0f));
		glUniformMatrix4fv(glGetUniformLocation(MyShader5->ID, "modelMat"), 1, GL_FALSE, glm::value_ptr(modelMat5));//��uniform��������λ�ƾ���
		glUniformMatrix4fv(glGetUniformLocation(MyShader5->ID, "viewMat"), 1, GL_FALSE, glm::value_ptr(viewMat));//��uniform���������ӽǾ���
		glUniformMatrix4fv(glGetUniformLocation(MyShader5->ID, "projMat"), 1, GL_FALSE, glm::value_ptr(projMat));//��uniform��������ͶӰ����
		glUniform3f(glGetUniformLocation(MyShader5->ID, "ObjColor"), 10.0f, 10.0f, 10.0f);//���ϵ���ɫ
		glUniform3f(glGetUniformLocation(MyShader5->ID, "AmbientColor"), 3.0f, 3.0f, 3.0f);//������
		glUniform3f(glGetUniformLocation(MyShader5->ID, "LightPos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);//��Դλ��
		glUniform3f(glGetUniformLocation(MyShader5->ID, "LightColor"), MyLight.color.x, MyLight.color.y, MyLight.color.z);//��Դ��ɫ
		glUniform3f(glGetUniformLocation(MyShader5->ID, "LightDirUniform"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);//��Դ����

		//ƽ�й�
		glUniform3f(glGetUniformLocation(MyShader5->ID, "lightdirectional.Pos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);
		glUniform3f(glGetUniformLocation(MyShader5->ID, "lightdirectional.DirToLight"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);
		glUniform3f(glGetUniformLocation(MyShader5->ID, "lightdirectional.Color"), MyLight.color.x, MyLight.color.y, MyLight.color.z);
		//���Դ0
		glUniform3f(glGetUniformLocation(MyShader5->ID, "lightpoint0.Pos"), MyLight0.position.x, MyLight0.position.y, MyLight0.position.z);
		glUniform3f(glGetUniformLocation(MyShader5->ID, "lightpoint0.DirToLight"), MyLight0.direction.x, MyLight0.direction.y, MyLight0.direction.z);
		glUniform3f(glGetUniformLocation(MyShader5->ID, "lightpoint0.Color"), MyLight0.color.x, MyLight0.color.y, MyLight0.color.z);
		glUniform1f(glGetUniformLocation(MyShader5->ID, "lightpoint0.constant"), MyLight0.constant);
		glUniform1f(glGetUniformLocation(MyShader5->ID, "lightpoint0.linear"), MyLight0.linear);
		glUniform1f(glGetUniformLocation(MyShader5->ID, "lightpoint0.quadratic"), MyLight0.quadratic);

		//�۹��
		glUniform3f(glGetUniformLocation(MyShader5->ID, "lightspot.Pos"), MyLightSpot.position.x, MyLightSpot.position.y, MyLightSpot.position.z);
		glUniform3f(glGetUniformLocation(MyShader5->ID, "lightspot.DirToLight"), MyLightSpot.direction.x, MyLightSpot.direction.y, MyLightSpot.direction.z);
		glUniform3f(glGetUniformLocation(MyShader5->ID, "lightspot.Color"), MyLightSpot.color.x, MyLightSpot.color.y, MyLightSpot.color.z);
		glUniform1f(glGetUniformLocation(MyShader5->ID, "lightspot.constant"), MyLightSpot.constant);
		glUniform1f(glGetUniformLocation(MyShader5->ID, "lightspot.linear"), MyLightSpot.linear);
		glUniform1f(glGetUniformLocation(MyShader5->ID, "lightspot.quadratic"), MyLightSpot.quadratic);
		glUniform1f(glGetUniformLocation(MyShader5->ID, "lightspot.cosInnerPhy"), MyLightSpot.cosInnerPhy);
		glUniform1f(glGetUniformLocation(MyShader5->ID, "lightspot.cosOutterPhy"), MyLightSpot.cosOutterPhy);

		glUniform3f(glGetUniformLocation(MyShader5->ID, "CameraPos"), MyCamera.Position.x, MyCamera.Position.y, MyCamera.Position.z);//�ӽ�λ�ã�Ӱ�쾵�淴�䣩
		MyMaterial5->shader->SetUniform3f("material.ambient", MyMaterial5->ambient);
		MyMaterial5->shader->SetUniform1i("material.diffuse", 11);
		MyMaterial5->shader->SetUniform1i("material.specular", 12);
		MyMaterial5->shader->SetUniform1f("material.shininess", MyMaterial5->shininess);
		model5.Draw(MyMaterial5->shader);
#pragma endregion

		//������
#pragma region Shader6 set and use, Draw model6
		MyShader6->use();
		modelMat6 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -10.0f, 0.0f));
		modelMat6 = glm::translate(modelMat6, glm::vec3((760 * sin(0.25f*(float)glfwGetTime())), 0.0f, -50 + 760 * cos(0.25f*(float)glfwGetTime())));
		modelMat6 = glm::scale(modelMat6, glm::vec3(300.0f, 300.0f, 300.0f));
		modelMat6 = glm::rotate(modelMat6, 0.6f*(float)glfwGetTime(), glm::vec3(0.0f, 1.0f, 0.0f));
		//modelMat1 = glm::rotate(modelMat1, (float)glfwGetTime(), glm::vec3(1.0f, 1.0f, 1.0f));
		glUniformMatrix4fv(glGetUniformLocation(MyShader6->ID, "modelMat"), 1, GL_FALSE, glm::value_ptr(modelMat6));//��uniform��������λ�ƾ���
		glUniformMatrix4fv(glGetUniformLocation(MyShader6->ID, "viewMat"), 1, GL_FALSE, glm::value_ptr(viewMat));//��uniform���������ӽǾ���
		glUniformMatrix4fv(glGetUniformLocation(MyShader6->ID, "projMat"), 1, GL_FALSE, glm::value_ptr(projMat));//��uniform��������ͶӰ����
		glUniform3f(glGetUniformLocation(MyShader6->ID, "ObjColor"), 1.0f, 1.0f, 1.0f);//���ϵ���ɫ
		glUniform3f(glGetUniformLocation(MyShader6->ID, "AmbientColor"), 1.0f, 1.0f, 1.0f);//������
		glUniform3f(glGetUniformLocation(MyShader6->ID, "LightPos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);//��Դλ��
		glUniform3f(glGetUniformLocation(MyShader6->ID, "LightColor"), MyLight.color.x, MyLight.color.y, MyLight.color.z);//��Դ��ɫ
		glUniform3f(glGetUniformLocation(MyShader6->ID, "LightDirUniform"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);//��Դ����

		//ƽ�й�
		glUniform3f(glGetUniformLocation(MyShader6->ID, "lightdirectional.Pos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);
		glUniform3f(glGetUniformLocation(MyShader6->ID, "lightdirectional.DirToLight"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);
		glUniform3f(glGetUniformLocation(MyShader6->ID, "lightdirectional.Color"), MyLight.color.x, MyLight.color.y, MyLight.color.z);
		//���Դ0
		glUniform3f(glGetUniformLocation(MyShader6->ID, "lightpoint0.Pos"), MyLight0.position.x, MyLight0.position.y, MyLight0.position.z);
		glUniform3f(glGetUniformLocation(MyShader6->ID, "lightpoint0.DirToLight"), MyLight0.direction.x, MyLight0.direction.y, MyLight0.direction.z);
		glUniform3f(glGetUniformLocation(MyShader6->ID, "lightpoint0.Color"), MyLight0.color.x, MyLight0.color.y, MyLight0.color.z);
		glUniform1f(glGetUniformLocation(MyShader6->ID, "lightpoint0.constant"), MyLight0.constant);
		glUniform1f(glGetUniformLocation(MyShader6->ID, "lightpoint0.linear"), MyLight0.linear);
		glUniform1f(glGetUniformLocation(MyShader6->ID, "lightpoint0.quadratic"), MyLight0.quadratic);

		//�۹��
		glUniform3f(glGetUniformLocation(MyShader6->ID, "lightspot.Pos"), MyLightSpot.position.x, MyLightSpot.position.y, MyLightSpot.position.z);
		glUniform3f(glGetUniformLocation(MyShader6->ID, "lightspot.DirToLight"), MyLightSpot.direction.x, MyLightSpot.direction.y, MyLightSpot.direction.z);
		glUniform3f(glGetUniformLocation(MyShader6->ID, "lightspot.Color"), MyLightSpot.color.x, MyLightSpot.color.y, MyLightSpot.color.z);
		glUniform1f(glGetUniformLocation(MyShader6->ID, "lightspot.constant"), MyLightSpot.constant);
		glUniform1f(glGetUniformLocation(MyShader6->ID, "lightspot.linear"), MyLightSpot.linear);
		glUniform1f(glGetUniformLocation(MyShader6->ID, "lightspot.quadratic"), MyLightSpot.quadratic);
		glUniform1f(glGetUniformLocation(MyShader6->ID, "lightspot.cosInnerPhy"), MyLightSpot.cosInnerPhy);
		glUniform1f(glGetUniformLocation(MyShader6->ID, "lightspot.cosOutterPhy"), MyLightSpot.cosOutterPhy);

		glUniform3f(glGetUniformLocation(MyShader6->ID, "CameraPos"), MyCamera.Position.x, MyCamera.Position.y, MyCamera.Position.z);//�ӽ�λ�ã�Ӱ�쾵�淴�䣩
		MyMaterial6->shader->SetUniform3f("material.ambient", MyMaterial6->ambient);
		MyMaterial6->shader->SetUniform1i("material.diffuse", 13);
		MyMaterial6->shader->SetUniform1i("material.specular", 14);
		MyMaterial6->shader->SetUniform1f("material.shininess", MyMaterial6->shininess);
		model6.Draw(MyMaterial6->shader);
#pragma endregion

		//����
#pragma region Shader7 set and use, Draw model7
		MyShader7->use();
		//modelMat4 = glm::translate(glm::mat4(1.0f), glm::vec3(60.0f, 0.0f, 5.0f));

		modelMat7 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -10.0f, 0.0f));
		//modelMat1 = glm::translate(modelMat1, glm::vec3((500 * sin(-0.05f*(float)glfwGetTime())), 0.0f, -50 + 500 * cos(-0.05f*(float)glfwGetTime())));
		modelMat7 = glm::translate(modelMat7, glm::vec3((120 * sin(1.5f*(float)glfwGetTime())) + (500 * sin(-0.05f*(float)glfwGetTime())), 0.0f, -50 + 120 * cos(1.5f*(float)glfwGetTime()) + 500 * cos(-0.05f*(float)glfwGetTime())));

		modelMat7 = glm::scale(modelMat7, glm::vec3(12.0f, 12.0f, 12.0f));
		modelMat7 = glm::rotate(modelMat7, -0.8f*(float)glfwGetTime(), glm::vec3(0.0f, 1.0f, 0.0f));
		//modelMat1 = glm::rotate(modelMat1, (float)glfwGetTime(), glm::vec3(1.0f, 1.0f, 1.0f));
		glUniformMatrix4fv(glGetUniformLocation(MyShader7->ID, "modelMat"), 1, GL_FALSE, glm::value_ptr(modelMat7));//��uniform��������λ�ƾ���
		glUniformMatrix4fv(glGetUniformLocation(MyShader7->ID, "viewMat"), 1, GL_FALSE, glm::value_ptr(viewMat));//��uniform���������ӽǾ���
		glUniformMatrix4fv(glGetUniformLocation(MyShader7->ID, "projMat"), 1, GL_FALSE, glm::value_ptr(projMat));//��uniform��������ͶӰ����
		glUniform3f(glGetUniformLocation(MyShader7->ID, "ObjColor"), 1.0f, 1.0f, 1.0f);//���ϵ���ɫ
		glUniform3f(glGetUniformLocation(MyShader7->ID, "AmbientColor"), 1.0f, 1.0f, 1.0f);//������
		glUniform3f(glGetUniformLocation(MyShader7->ID, "LightPos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);//��Դλ��
		glUniform3f(glGetUniformLocation(MyShader7->ID, "LightColor"), MyLight.color.x, MyLight.color.y, MyLight.color.z);//��Դ��ɫ
		glUniform3f(glGetUniformLocation(MyShader7->ID, "LightDirUniform"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);//��Դ����

		//ƽ�й�
		glUniform3f(glGetUniformLocation(MyShader7->ID, "lightdirectional.Pos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);
		glUniform3f(glGetUniformLocation(MyShader7->ID, "lightdirectional.DirToLight"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);
		glUniform3f(glGetUniformLocation(MyShader7->ID, "lightdirectional.Color"), MyLight.color.x, MyLight.color.y, MyLight.color.z);
		//���Դ0
		glUniform3f(glGetUniformLocation(MyShader7->ID, "lightpoint0.Pos"), MyLight0.position.x, MyLight0.position.y, MyLight0.position.z);
		glUniform3f(glGetUniformLocation(MyShader7->ID, "lightpoint0.DirToLight"), MyLight0.direction.x, MyLight0.direction.y, MyLight0.direction.z);
		glUniform3f(glGetUniformLocation(MyShader7->ID, "lightpoint0.Color"), MyLight0.color.x, MyLight0.color.y, MyLight0.color.z);
		glUniform1f(glGetUniformLocation(MyShader7->ID, "lightpoint0.constant"), MyLight0.constant);
		glUniform1f(glGetUniformLocation(MyShader7->ID, "lightpoint0.linear"), MyLight0.linear);
		glUniform1f(glGetUniformLocation(MyShader7->ID, "lightpoint0.quadratic"), MyLight0.quadratic);

		//�۹��
		glUniform3f(glGetUniformLocation(MyShader7->ID, "lightspot.Pos"), MyLightSpot.position.x, MyLightSpot.position.y, MyLightSpot.position.z);
		glUniform3f(glGetUniformLocation(MyShader7->ID, "lightspot.DirToLight"), MyLightSpot.direction.x, MyLightSpot.direction.y, MyLightSpot.direction.z);
		glUniform3f(glGetUniformLocation(MyShader7->ID, "lightspot.Color"), MyLightSpot.color.x, MyLightSpot.color.y, MyLightSpot.color.z);
		glUniform1f(glGetUniformLocation(MyShader7->ID, "lightspot.constant"), MyLightSpot.constant);
		glUniform1f(glGetUniformLocation(MyShader7->ID, "lightspot.linear"), MyLightSpot.linear);
		glUniform1f(glGetUniformLocation(MyShader7->ID, "lightspot.quadratic"), MyLightSpot.quadratic);
		glUniform1f(glGetUniformLocation(MyShader7->ID, "lightspot.cosInnerPhy"), MyLightSpot.cosInnerPhy);
		glUniform1f(glGetUniformLocation(MyShader7->ID, "lightspot.cosOutterPhy"), MyLightSpot.cosOutterPhy);

		glUniform3f(glGetUniformLocation(MyShader7->ID, "CameraPos"), MyCamera.Position.x, MyCamera.Position.y, MyCamera.Position.z);//�ӽ�λ�ã�Ӱ�쾵�淴�䣩
		MyMaterial7->shader->SetUniform3f("material.ambient", MyMaterial7->ambient);
		MyMaterial7->shader->SetUniform1i("material.diffuse", 4);
		MyMaterial7->shader->SetUniform1i("material.specular", 2);
		MyMaterial7->shader->SetUniform1f("material.shininess", MyMaterial7->shininess);
		model7.Draw(MyMaterial7->shader);
#pragma endregion

		//���ܲ�
#pragma region Shader8 set and use, Draw model8
		MyShader8->use();
		//modelMat4 = glm::translate(glm::mat4(1.0f), glm::vec3(60.0f, 0.0f, 5.0f));

		modelMat8 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -10.0f, 0.0f));
		//modelMat1 = glm::translate(modelMat1, glm::vec3((500 * sin(-0.05f*(float)glfwGetTime())), 0.0f, -50 + 500 * cos(-0.05f*(float)glfwGetTime())));
		modelMat8 = glm::translate(modelMat8, glm::vec3((110 * sin(-1.5f*(float)glfwGetTime())) + (500 * sin(-0.05f*(float)glfwGetTime())), 40.0f, -50 + 110 * cos(-1.5f*(float)glfwGetTime()) + 500 * cos(-0.05f*(float)glfwGetTime())));

		modelMat8 = glm::scale(modelMat8, glm::vec3(8.0f, 8.0f, 8.0f));
		modelMat8 = glm::rotate(modelMat8, -0.8f*(float)glfwGetTime(), glm::vec3(0.0f, 1.0f, 0.0f));
		//modelMat1 = glm::rotate(modelMat1, (float)glfwGetTime(), glm::vec3(1.0f, 1.0f, 1.0f));
		glUniformMatrix4fv(glGetUniformLocation(MyShader8->ID, "modelMat"), 1, GL_FALSE, glm::value_ptr(modelMat8));//��uniform��������λ�ƾ���
		glUniformMatrix4fv(glGetUniformLocation(MyShader8->ID, "viewMat"), 1, GL_FALSE, glm::value_ptr(viewMat));//��uniform���������ӽǾ���
		glUniformMatrix4fv(glGetUniformLocation(MyShader8->ID, "projMat"), 1, GL_FALSE, glm::value_ptr(projMat));//��uniform��������ͶӰ����
		glUniform3f(glGetUniformLocation(MyShader8->ID, "ObjColor"), 1.0f, 1.0f, 1.0f);//���ϵ���ɫ
		glUniform3f(glGetUniformLocation(MyShader8->ID, "AmbientColor"), 1.0f, 1.0f, 1.0f);//������
		glUniform3f(glGetUniformLocation(MyShader8->ID, "LightPos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);//��Դλ��
		glUniform3f(glGetUniformLocation(MyShader8->ID, "LightColor"), MyLight.color.x, MyLight.color.y, MyLight.color.z);//��Դ��ɫ
		glUniform3f(glGetUniformLocation(MyShader8->ID, "LightDirUniform"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);//��Դ����

		//ƽ�й�
		glUniform3f(glGetUniformLocation(MyShader8->ID, "lightdirectional.Pos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);
		glUniform3f(glGetUniformLocation(MyShader8->ID, "lightdirectional.DirToLight"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);
		glUniform3f(glGetUniformLocation(MyShader8->ID, "lightdirectional.Color"), MyLight.color.x, MyLight.color.y, MyLight.color.z);
		//���Դ0
		glUniform3f(glGetUniformLocation(MyShader8->ID, "lightpoint0.Pos"), MyLight0.position.x, MyLight0.position.y, MyLight0.position.z);
		glUniform3f(glGetUniformLocation(MyShader8->ID, "lightpoint0.DirToLight"), MyLight0.direction.x, MyLight0.direction.y, MyLight0.direction.z);
		glUniform3f(glGetUniformLocation(MyShader8->ID, "lightpoint0.Color"), MyLight0.color.x, MyLight0.color.y, MyLight0.color.z);
		glUniform1f(glGetUniformLocation(MyShader8->ID, "lightpoint0.constant"), MyLight0.constant);
		glUniform1f(glGetUniformLocation(MyShader8->ID, "lightpoint0.linear"), MyLight0.linear);
		glUniform1f(glGetUniformLocation(MyShader8->ID, "lightpoint0.quadratic"), MyLight0.quadratic);

		//�۹��
		glUniform3f(glGetUniformLocation(MyShader8->ID, "lightspot.Pos"), MyLightSpot.position.x, MyLightSpot.position.y, MyLightSpot.position.z);
		glUniform3f(glGetUniformLocation(MyShader8->ID, "lightspot.DirToLight"), MyLightSpot.direction.x, MyLightSpot.direction.y, MyLightSpot.direction.z);
		glUniform3f(glGetUniformLocation(MyShader8->ID, "lightspot.Color"), MyLightSpot.color.x, MyLightSpot.color.y, MyLightSpot.color.z);
		glUniform1f(glGetUniformLocation(MyShader8->ID, "lightspot.constant"), MyLightSpot.constant);
		glUniform1f(glGetUniformLocation(MyShader8->ID, "lightspot.linear"), MyLightSpot.linear);
		glUniform1f(glGetUniformLocation(MyShader8->ID, "lightspot.quadratic"), MyLightSpot.quadratic);
		glUniform1f(glGetUniformLocation(MyShader8->ID, "lightspot.cosInnerPhy"), MyLightSpot.cosInnerPhy);
		glUniform1f(glGetUniformLocation(MyShader8->ID, "lightspot.cosOutterPhy"), MyLightSpot.cosOutterPhy);

		glUniform3f(glGetUniformLocation(MyShader8->ID, "CameraPos"), MyCamera.Position.x, MyCamera.Position.y, MyCamera.Position.z);//�ӽ�λ�ã�Ӱ�쾵�淴�䣩
		MyMaterial8->shader->SetUniform3f("material.ambient", MyMaterial8->ambient);
		MyMaterial8->shader->SetUniform1i("material.diffuse", 6);
		MyMaterial8->shader->SetUniform1i("material.specular", 2);
		MyMaterial8->shader->SetUniform1f("material.shininess", MyMaterial8->shininess);
		model8.Draw(MyMaterial8->shader);
#pragma endregion 

		//������
#pragma region Shader9 set and use, Draw model9
		MyShader9->use();
		//modelMat4 = glm::translate(glm::mat4(1.0f), glm::vec3(60.0f, 0.0f, 5.0f));

		modelMat9 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -10.0f, 0.0f));
		//modelMat1 = glm::translate(modelMat1, glm::vec3((500 * sin(-0.05f*(float)glfwGetTime())), 0.0f, -50 + 500 * cos(-0.05f*(float)glfwGetTime())));
		modelMat9 = glm::translate(modelMat9, glm::vec3((110 * sin(-1.0f*(float)glfwGetTime())) + (500 * sin(-0.05f*(float)glfwGetTime())), -40.0f, -50 + 110 * cos(-1.0f*(float)glfwGetTime()) + 500 * cos(-0.05f*(float)glfwGetTime())));

		modelMat9 = glm::scale(modelMat9, glm::vec3(4.0f, 4.0f, 4.0f));
		modelMat9 = glm::rotate(modelMat9, -1.6f*(float)glfwGetTime(), glm::vec3(0.0f, 1.0f, 0.0f));
		//modelMat1 = glm::rotate(modelMat1, (float)glfwGetTime(), glm::vec3(1.0f, 1.0f, 1.0f));
		glUniformMatrix4fv(glGetUniformLocation(MyShader9->ID, "modelMat"), 1, GL_FALSE, glm::value_ptr(modelMat9));//��uniform��������λ�ƾ���
		glUniformMatrix4fv(glGetUniformLocation(MyShader9->ID, "viewMat"), 1, GL_FALSE, glm::value_ptr(viewMat));//��uniform���������ӽǾ���
		glUniformMatrix4fv(glGetUniformLocation(MyShader9->ID, "projMat"), 1, GL_FALSE, glm::value_ptr(projMat));//��uniform��������ͶӰ����
		glUniform3f(glGetUniformLocation(MyShader9->ID, "ObjColor"), 1.0f, 1.0f, 1.0f);//���ϵ���ɫ
		glUniform3f(glGetUniformLocation(MyShader9->ID, "AmbientColor"), 1.0f, 1.0f, 1.0f);//������
		glUniform3f(glGetUniformLocation(MyShader9->ID, "LightPos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);//��Դλ��
		glUniform3f(glGetUniformLocation(MyShader9->ID, "LightColor"), MyLight.color.x, MyLight.color.y, MyLight.color.z);//��Դ��ɫ
		glUniform3f(glGetUniformLocation(MyShader9->ID, "LightDirUniform"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);//��Դ����

		//ƽ�й�
		glUniform3f(glGetUniformLocation(MyShader9->ID, "lightdirectional.Pos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);
		glUniform3f(glGetUniformLocation(MyShader9->ID, "lightdirectional.DirToLight"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);
		glUniform3f(glGetUniformLocation(MyShader9->ID, "lightdirectional.Color"), MyLight.color.x, MyLight.color.y, MyLight.color.z);
		//���Դ0
		glUniform3f(glGetUniformLocation(MyShader9->ID, "lightpoint0.Pos"), MyLight0.position.x, MyLight0.position.y, MyLight0.position.z);
		glUniform3f(glGetUniformLocation(MyShader9->ID, "lightpoint0.DirToLight"), MyLight0.direction.x, MyLight0.direction.y, MyLight0.direction.z);
		glUniform3f(glGetUniformLocation(MyShader9->ID, "lightpoint0.Color"), MyLight0.color.x, MyLight0.color.y, MyLight0.color.z);
		glUniform1f(glGetUniformLocation(MyShader9->ID, "lightpoint0.constant"), MyLight0.constant);
		glUniform1f(glGetUniformLocation(MyShader9->ID, "lightpoint0.linear"), MyLight0.linear);
		glUniform1f(glGetUniformLocation(MyShader9->ID, "lightpoint0.quadratic"), MyLight0.quadratic);

		//�۹��
		glUniform3f(glGetUniformLocation(MyShader9->ID, "lightspot.Pos"), MyLightSpot.position.x, MyLightSpot.position.y, MyLightSpot.position.z);
		glUniform3f(glGetUniformLocation(MyShader9->ID, "lightspot.DirToLight"), MyLightSpot.direction.x, MyLightSpot.direction.y, MyLightSpot.direction.z);
		glUniform3f(glGetUniformLocation(MyShader9->ID, "lightspot.Color"), MyLightSpot.color.x, MyLightSpot.color.y, MyLightSpot.color.z);
		glUniform1f(glGetUniformLocation(MyShader9->ID, "lightspot.constant"), MyLightSpot.constant);
		glUniform1f(glGetUniformLocation(MyShader9->ID, "lightspot.linear"), MyLightSpot.linear);
		glUniform1f(glGetUniformLocation(MyShader9->ID, "lightspot.quadratic"), MyLightSpot.quadratic);
		glUniform1f(glGetUniformLocation(MyShader9->ID, "lightspot.cosInnerPhy"), MyLightSpot.cosInnerPhy);
		glUniform1f(glGetUniformLocation(MyShader9->ID, "lightspot.cosOutterPhy"), MyLightSpot.cosOutterPhy);

		glUniform3f(glGetUniformLocation(MyShader9->ID, "CameraPos"), MyCamera.Position.x, MyCamera.Position.y, MyCamera.Position.z);//�ӽ�λ�ã�Ӱ�쾵�淴�䣩
		MyMaterial9->shader->SetUniform3f("material.ambient", MyMaterial9->ambient);
		MyMaterial9->shader->SetUniform1i("material.diffuse", 8);
		MyMaterial9->shader->SetUniform1i("material.specular", 2);
		MyMaterial9->shader->SetUniform1f("material.shininess", MyMaterial9->shininess);
		model9.Draw(MyMaterial9->shader);
#pragma endregion 

		//��֭
#pragma region Shader10 set and use, Draw model10
		MyShader10->use();
		//modelMat4 = glm::translate(glm::mat4(1.0f), glm::vec3(60.0f, 0.0f, 5.0f));

		modelMat10 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -10.0f, 0.0f));
		//modelMat1 = glm::translate(modelMat1, glm::vec3((500 * sin(-0.05f*(float)glfwGetTime())), 0.0f, -50 + 500 * cos(-0.05f*(float)glfwGetTime())));
		modelMat10 = glm::translate(modelMat10, glm::vec3((110 * sin(-1.0f*(float)glfwGetTime())) + (760 * sin(0.25f*(float)glfwGetTime())), 0.0f, -50 + 110 * cos(-1.0f*(float)glfwGetTime()) + 760 * cos(0.25f*(float)glfwGetTime())));

		modelMat10 = glm::scale(modelMat10, glm::vec3(4.0f, 4.0f, 4.0f));
		modelMat10 = glm::rotate(modelMat10, -1.6f*(float)glfwGetTime(), glm::vec3(0.0f, 1.0f, 0.0f));
		//modelMat1 = glm::rotate(modelMat1, (float)glfwGetTime(), glm::vec3(1.0f, 1.0f, 1.0f));
		glUniformMatrix4fv(glGetUniformLocation(MyShader10->ID, "modelMat"), 1, GL_FALSE, glm::value_ptr(modelMat10));//��uniform��������λ�ƾ���
		glUniformMatrix4fv(glGetUniformLocation(MyShader10->ID, "viewMat"), 1, GL_FALSE, glm::value_ptr(viewMat));//��uniform���������ӽǾ���
		glUniformMatrix4fv(glGetUniformLocation(MyShader10->ID, "projMat"), 1, GL_FALSE, glm::value_ptr(projMat));//��uniform��������ͶӰ����
		glUniform3f(glGetUniformLocation(MyShader10->ID, "ObjColor"), 1.0f, 1.0f, 1.0f);//���ϵ���ɫ
		glUniform3f(glGetUniformLocation(MyShader10->ID, "AmbientColor"), 1.0f, 1.0f, 1.0f);//������
		glUniform3f(glGetUniformLocation(MyShader10->ID, "LightPos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);//��Դλ��
		glUniform3f(glGetUniformLocation(MyShader10->ID, "LightColor"), MyLight.color.x, MyLight.color.y, MyLight.color.z);//��Դ��ɫ
		glUniform3f(glGetUniformLocation(MyShader10->ID, "LightDirUniform"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);//��Դ����

		//ƽ�й�
		glUniform3f(glGetUniformLocation(MyShader10->ID, "lightdirectional.Pos"), MyLight.position.x, MyLight.position.y, MyLight.position.z);
		glUniform3f(glGetUniformLocation(MyShader10->ID, "lightdirectional.DirToLight"), MyLight.direction.x, MyLight.direction.y, MyLight.direction.z);
		glUniform3f(glGetUniformLocation(MyShader10->ID, "lightdirectional.Color"), MyLight.color.x, MyLight.color.y, MyLight.color.z);
		//���Դ0
		glUniform3f(glGetUniformLocation(MyShader10->ID, "lightpoint0.Pos"), MyLight0.position.x, MyLight0.position.y, MyLight0.position.z);
		glUniform3f(glGetUniformLocation(MyShader10->ID, "lightpoint0.DirToLight"), MyLight0.direction.x, MyLight0.direction.y, MyLight0.direction.z);
		glUniform3f(glGetUniformLocation(MyShader10->ID, "lightpoint0.Color"), MyLight0.color.x, MyLight0.color.y, MyLight0.color.z);
		glUniform1f(glGetUniformLocation(MyShader10->ID, "lightpoint0.constant"), MyLight0.constant);
		glUniform1f(glGetUniformLocation(MyShader10->ID, "lightpoint0.linear"), MyLight0.linear);
		glUniform1f(glGetUniformLocation(MyShader10->ID, "lightpoint0.quadratic"), MyLight0.quadratic);

		//�۹��
		glUniform3f(glGetUniformLocation(MyShader10->ID, "lightspot.Pos"), MyLightSpot.position.x, MyLightSpot.position.y, MyLightSpot.position.z);
		glUniform3f(glGetUniformLocation(MyShader10->ID, "lightspot.DirToLight"), MyLightSpot.direction.x, MyLightSpot.direction.y, MyLightSpot.direction.z);
		glUniform3f(glGetUniformLocation(MyShader10->ID, "lightspot.Color"), MyLightSpot.color.x, MyLightSpot.color.y, MyLightSpot.color.z);
		glUniform1f(glGetUniformLocation(MyShader10->ID, "lightspot.constant"), MyLightSpot.constant);
		glUniform1f(glGetUniformLocation(MyShader10->ID, "lightspot.linear"), MyLightSpot.linear);
		glUniform1f(glGetUniformLocation(MyShader10->ID, "lightspot.quadratic"), MyLightSpot.quadratic);
		glUniform1f(glGetUniformLocation(MyShader10->ID, "lightspot.cosInnerPhy"), MyLightSpot.cosInnerPhy);
		glUniform1f(glGetUniformLocation(MyShader10->ID, "lightspot.cosOutterPhy"), MyLightSpot.cosOutterPhy);

		glUniform3f(glGetUniformLocation(MyShader10->ID, "CameraPos"), MyCamera.Position.x, MyCamera.Position.y, MyCamera.Position.z);//�ӽ�λ�ã�Ӱ�쾵�淴�䣩
		MyMaterial10->shader->SetUniform3f("material.ambient", MyMaterial10->ambient);
		MyMaterial10->shader->SetUniform1i("material.diffuse", 10);
		MyMaterial10->shader->SetUniform1i("material.specular", 2);
		MyMaterial10->shader->SetUniform1f("material.shininess", MyMaterial10->shininess);
		model10.Draw(MyMaterial10->shader);
#pragma endregion 

		//Clean up, prepare for next render loop
		glfwSwapBuffers(MyWindow);//ˢ��
		glfwPollEvents();//��ȡ����
		MyCamera.UpdateCameraPosition();

	}
	//Exit program
	glfwTerminate();
	return 0;
}
	
}
